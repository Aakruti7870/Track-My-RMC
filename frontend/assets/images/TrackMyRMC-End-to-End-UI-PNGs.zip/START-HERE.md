# TrackMyRMC · Product design review

A proposed UX for the ready-mix journey from role sign-in through quotation, confirmed delivery, proof and billing. The order, people, plants, map, quantities and prices are illustrative. The screens are mockups.

## Start with these journeys

| Chapter | Goal |
| --- | --- |
| 01 · Entry and Customer Home | Sign in, see active delivery when applicable, set or change the discovery site, find plants |
| 02 · Discover and quote | Browse and compare, check plant verification, submit a request, review an official quote |
| 03 · Order and payment | Specify concrete and delivery, confirm details, save a draft, complete KYC if required, review accepted terms |
| 04 · Delivery and customer tools | Track each mixer, retrieve challan, proof and invoice, report an issue, plan the next pour |
| 05 · Supplier | Set up a plant, review RFQs, send quotes, accept orders and commercial terms |
| 06 · Plant to jobsite | Assign load, batch, record quality, release, track assigned trip, capture proof |
| 07 · Operations and closeout | Fleet, inventory, incidents, workforce, invoicing and customer record |
| 08 · Web review | Central Admin plant review and visibility with delegated Authority support |

Open the PNG boards for a quick walkthrough. The individually numbered PNGs are in `screens/`. The screen index links each image to the code or to the existing implementation it extends. Customer screens are composed for a 390 px-wide viewport. Desktop review screens use a 1440 px viewport. Long forms show the complete scrollable page.

## Decisions and priorities

**P0 · Customer Home.** Keep Home, Orders, New, Plants and More as the five customer navigation items. Keep the carousel short and show up to two site-relevant plants directly underneath. When a truck is dispatched or en route, place the active delivery strip above the carousel. Link to distinct load records when more than one mixer is on the road. Use one actionable destination per card.

**P0 · Site-aware discovery.** Prefer an explicitly selected site for the current visit, then the saved default. Use the only saved site automatically. With multiple saved sites and no default, use a previously selected site if available, or ask the user to choose. With no saved site, offer a manual address or a user-initiated device-location lookup. If the customer already enabled location access, nearby results can be labeled as current-location browsing. Confirm the actual jobsite before sending an RFQ or order. Changing the selected site refreshes nearby results and invalidates any old serviceability assumption. Existing orders retain their confirmed delivery site. Resolve older saved addresses without coordinates via an address or pin selection, and preserve the address when location consent is declined.

**P0 · Quote, order, dispatch and proof.** Keep the same order ID across customer, supplier, dispatcher, driver and billing. Record grade, ordered volume, pump preference, jobsite, contact, access, requested delivery time and supplier confirmation. Show official pricing as concrete, transport, pumping, taxes and total, with validity and terms. Track each load by load ID, mixer, batch reference, challan, timestamp and delivered volume. Prefer a named status and last update over an unsupported ETA. Capture proof against the load and show when server acceptance is pending. Record an issue against the specific delivery and preserve the evidentiary trail. Apply authorization and privacy boundaries at data reads and writes.

**P1 · Plant eligibility and trust.** Distinguish a platform-verified plant, a serviceability check, and a booked supplier slot. An unverified place listing gets an order review or an enquiry. Keep the public labels consistent with the routes and show the request in Orders. Display only approved documents and capability information. Plant verification and serviceability are distinct facts.

**P1 · Services and account.** Put project tools, pump rental, materials and labour in Services under More. Put saved project sites, estimates, contacts and related records in Project Hub. Keep profile, consent and privacy controls separate from order history. Offer DigiLocker at the appropriate existing verification step while preserving the draft. Display provider-confirmed or reconciled payment state, and show approved checkout only when available. Do not derive a paid state from a browser return.

**P2 · Release validation.** Verify representative task flows at 360 and 390 dp with keyboard, large text and both themes. Compare first-time users and repeat buyers on successful site selection, quote completion and tracking access from Home. Monitor conversion to a serviceable request and track time-to-first-update or time-to-tracking. Check real devices, provider states, permissions and backend transitions independently.

## Code baseline and scope

Repository: https://github.com/Aakruti7870/Track-My-RMC  
Reviewed main commit: https://github.com/Aakruti7870/Track-My-RMC/commit/27a9e2bd626267a260b603bd4f12cc5963f98a82

The selected flow uses the customer, plant owner, dispatcher, operator, quality engineer, driver, fleet, stores, supervisor, billing and privileged web routes. It focuses on the supply-chain journey and its supporting screens. It does not attempt screenshot coverage for every reusable staff route, every settings page, or every marketing, payroll and governance workflow. The repository route inventory included in this archive lists the mobile route files that were reviewed at tree level. Visual states can share a route and are not claims about live provider activation.

### Implementation checks from the review

- `frontend/app/customer/index.tsx` uses Home data that includes an active order. The design gives this order a dedicated priority state and adds a lightweight site-aware plant preview.
- `frontend/app/customer/plants.tsx` already handles registered and nearby Google listings and uses location consent. Home should reuse discovery and visibility rules, with the selected site supplied as the search context.
- `frontend/app/customer/sites.tsx` and `backend/src/routes/customer_routes.rs` already expose saved-site data and an `is_default` field. The reviewed site form marks the first site as default. Editing a previous default and persisting the last selection are design changes that need corresponding state and authorized write support.
- `frontend/app/new-order.tsx`, `frontend/app/customer/request-quotation.tsx` and `frontend/app/customer/quotations.tsx` support order drafts, lead/request routing, and quote decisions. Step-by-step presentation, selected-site propagation and reordering are interface proposals.
- `frontend/app/track/[id].tsx`, `frontend/app/challan/[id].tsx`, `frontend/app/trip/[id].tsx` and `frontend/app/pod/[id].tsx` provide the primary delivery surfaces. A persistent pending-proof state needs a durable permission-scoped draft, state recovery and safe retry behavior before release. The unified documents view is a proposal.
- Privileged routes are implemented in `admin-web/`, separate from the Expo client. Access remains role- and capability-scoped. Screens here represent the approval, visibility and support handoffs needed by the supply chain.
- The mockup prices are sample values. GST, credit, quote validity, payment, contract terms, schedule and ETA must come from the corresponding authoritative workflow.

## Research

- NRMCA CIP 31, Ordering Ready Mixed Concrete: https://www.armofmn.com/assets/pdf/31pr/
- NRMCA Quality Manual, ordering and dispatch: https://www.nrmca.org/wp-content/uploads/2019/11/QMS.pdf
- Cemex Go, ordering, tracking and paperless services: https://www.cemex.co.uk/services/go
- UltraTech Customer Connect, order and dispatch information and electronic delivery evidence: https://play.google.com/store/apps/details?id=com.utcl.keyaccount
- Nielsen Norman Group, homepage priorities and clear calls to action: https://www.nngroup.com/articles/homepage-design-principles/
- Baymard, carousel requirements: https://baymard.com/blog/homepage-carousel
- Baymard, order-tracking details: https://baymard.com/research-articles/integrate-tracking-info
