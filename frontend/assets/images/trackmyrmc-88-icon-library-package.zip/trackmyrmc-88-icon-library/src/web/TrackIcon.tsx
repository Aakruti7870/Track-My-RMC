import React from "react";
import {
  TrackIconName,
  TrackIconProps,
  TRACK_ICON_REGISTRY,
  resolveTrackIconInnerSvg,
} from "../registry/iconRegistry";

/**
 * Web TrackIcon component using CSS px sizing and master viewBox="0 0 64 64".
 * Example: <TrackIcon name="new-order" size={52} />
 */
export const TrackIcon: React.FC<TrackIconProps> = ({
  name,
  size = 24,
  theme = "light",
  variant = "default",
  accessibilityLabel,
  className,
}) => {
  const meta = TRACK_ICON_REGISTRY[name];
  const label = accessibilityLabel ?? meta?.accessibilityLabel ?? name;
  const innerHtml = resolveTrackIconInnerSvg(name, size, theme, variant);

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={`${size}px`}
      height={`${size}px`}
      viewBox="0 0 64 64"
      fill="none"
      role="img"
      aria-label={label}
      className={className}
      style={{ width: `${size}px`, height: `${size}px`, display: "inline-block", flexShrink: 0 }}
      dangerouslySetInnerHTML={{ __html: innerHtml }}
    />
  );
};

// Named PascalCase Component Exports for all 88 TrackMyRMC Icons
export const HomeIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="home" {...props} />
);

export const OrdersIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="orders" {...props} />
);

export const PlantsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="plants" {...props} />
);

export const MoreIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="more" {...props} />
);

export const BackIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="back" {...props} />
);

export const SearchIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="search" {...props} />
);

export const FilterIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="filter" {...props} />
);

export const SettingsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="settings" {...props} />
);

export const NotificationsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="notifications" {...props} />
);

export const ProfileIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="profile" {...props} />
);

export const SupportIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="support" {...props} />
);

export const LogoutIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="logout" {...props} />
);

export const NewOrderIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="new-order" {...props} />
);

export const NearbyRmcPlantsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="nearby-rmc-plants" {...props} />
);

export const LiveOrderTrackingIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="live-order-tracking" {...props} />
);

export const MyOrdersIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="my-orders" {...props} />
);

export const QuotationsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="quotations" {...props} />
);

export const ProjectAndSiteHubIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="project-and-site-hub" {...props} />
);

export const ConcretePourPlannerIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="concrete-pour-planner" {...props} />
);

export const ReceivingAndQualityGuideIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="receiving-and-quality-guide" {...props} />
);

export const CubeTestFollowUpIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="cube-test-follow-up" {...props} />
);

export const SavedSitesIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="saved-sites" {...props} />
);

export const ComparePlantsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="compare-plants" {...props} />
);

export const FreeRmcToolsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="free-rmc-tools" {...props} />
);

export const DocumentsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="documents" {...props} />
);

export const KycVerificationIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="kyc-verification" {...props} />
);

export const PlantDashboardIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="plant-dashboard" {...props} />
);

export const PlantOrdersIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="plant-orders" {...props} />
);

export const ProductionAndDispatchIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="production-and-dispatch" {...props} />
);

export const BillingAndLedgerIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="billing-and-ledger" {...props} />
);

export const BillingHistoryIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="billing-history" {...props} />
);

export const QuotationRequestsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="quotation-requests" {...props} />
);

export const IncidentRegisterIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="incident-register" {...props} />
);

export const PremiumAndPromotionsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="premium-and-promotions" {...props} />
);

export const PlantProfileIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="plant-profile" {...props} />
);

export const RateCardsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="rate-cards" {...props} />
);

export const PlantReportsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="plant-reports" {...props} />
);

export const PlantStaffIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="plant-staff" {...props} />
);

export const AdminDashboardIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="admin-dashboard" {...props} />
);

export const PlantOrderManagementIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="plant-order-management" {...props} />
);

export const PlantOnboardingReviewIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="plant-onboarding-review" {...props} />
);

export const DispatchQueueIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="dispatch-queue" {...props} />
);

export const FleetAvailabilityIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="fleet-availability" {...props} />
);

export const DriverAssignmentIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="driver-assignment" {...props} />
);

export const DeliveryChallanIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="delivery-challan" {...props} />
);

export const ProofOfDeliveryIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="proof-of-delivery" {...props} />
);

export const ProductionQueueIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="production-queue" {...props} />
);

export const BatchingOperationsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="batching-operations" {...props} />
);

export const MixDesignsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="mix-designs" {...props} />
);

export const QualityRegisterIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="quality-register" {...props} />
);

export const ConcreteCubeTestingIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="concrete-cube-testing" {...props} />
);

export const MaterialConsumptionIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="material-consumption" {...props} />
);

export const ProductionReportIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="production-report" {...props} />
);

export const TransitMixerFleetIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="transit-mixer-fleet" {...props} />
);

export const AssignedTripsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="assigned-trips" {...props} />
);

export const GpsLiveLocationIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="gps-live-location" {...props} />
);

export const DriversIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="drivers" {...props} />
);

export const VehicleMaintenanceIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="vehicle-maintenance" {...props} />
);

export const DieselLedgerIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="diesel-ledger" {...props} />
);

export const DriverAttendanceIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="driver-attendance" {...props} />
);

export const EmergencySosIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="emergency-sos" {...props} />
);

export const TripHistoryIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="trip-history" {...props} />
);

export const StockRegisterIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="stock-register" {...props} />
);

export const MaterialInventoryIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="material-inventory" {...props} />
);

export const SuppliersIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="suppliers" {...props} />
);

export const PurchasesIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="purchases" {...props} />
);

export const MaterialReceiptsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="material-receipts" {...props} />
);

export const LowStockAlertIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="low-stock-alert" {...props} />
);

export const StoreDashboardIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="store-dashboard" {...props} />
);

export const BillingIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="billing" {...props} />
);

export const LedgerIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="ledger" {...props} />
);

export const ExpensesIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="expenses" {...props} />
);

export const PayrollIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="payroll" {...props} />
);

export const AttendanceIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="attendance" {...props} />
);

export const ShiftRosterIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="shift-roster" {...props} />
);

export const MyPayslipIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="my-payslip" {...props} />
);

export const WorkforceReportsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="workforce-reports" {...props} />
);

export const EmployeeMasterAndSalaryIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="employee-master-and-salary" {...props} />
);

export const PayrollClosureIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="payroll-closure" {...props} />
);

export const VerifiedPlantIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="verified-plant" {...props} />
);

export const UnverifiedPlantIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="unverified-plant" {...props} />
);

export const KycVerifiedIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="kyc-verified" {...props} />
);

export const PendingApprovalIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="pending-approval" {...props} />
);

export const OrderEnabledIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="order-enabled" {...props} />
);

export const RestrictedAccessIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="restricted-access" {...props} />
);

export const PermissionSettingsIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="permission-settings" {...props} />
);

export const WarningIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="warning" {...props} />
);

export const SuccessIcon: React.FC<Omit<TrackIconProps, "name">> = (props) => (
  <TrackIcon name="success" {...props} />
);
