/**
 * TrackMyRMC Complete 88-Icon TypeScript Registry
 * Master Artboard: 64 x 64 (viewBox="0 0 64 64")
 * Default Display Size: 24 x 24 (dp on React Native, CSS px on Web)
 * Palette: Mirage #16232A | Wild Sand #E4EEF0 | Accents: #3B82F6, #10B981, #F59E0B, #06B6D4, #8B5CF6, #EF4444, #FACC15
 */

export type TrackIconName =
  "home" |
  "orders" |
  "plants" |
  "more" |
  "back" |
  "search" |
  "filter" |
  "settings" |
  "notifications" |
  "profile" |
  "support" |
  "logout" |
  "new-order" |
  "nearby-rmc-plants" |
  "live-order-tracking" |
  "my-orders" |
  "quotations" |
  "project-and-site-hub" |
  "concrete-pour-planner" |
  "receiving-and-quality-guide" |
  "cube-test-follow-up" |
  "saved-sites" |
  "compare-plants" |
  "free-rmc-tools" |
  "documents" |
  "kyc-verification" |
  "plant-dashboard" |
  "plant-orders" |
  "production-and-dispatch" |
  "billing-and-ledger" |
  "billing-history" |
  "quotation-requests" |
  "incident-register" |
  "premium-and-promotions" |
  "plant-profile" |
  "rate-cards" |
  "plant-reports" |
  "plant-staff" |
  "admin-dashboard" |
  "plant-order-management" |
  "plant-onboarding-review" |
  "dispatch-queue" |
  "fleet-availability" |
  "driver-assignment" |
  "delivery-challan" |
  "proof-of-delivery" |
  "production-queue" |
  "batching-operations" |
  "mix-designs" |
  "quality-register" |
  "concrete-cube-testing" |
  "material-consumption" |
  "production-report" |
  "transit-mixer-fleet" |
  "assigned-trips" |
  "gps-live-location" |
  "drivers" |
  "vehicle-maintenance" |
  "diesel-ledger" |
  "driver-attendance" |
  "emergency-sos" |
  "trip-history" |
  "stock-register" |
  "material-inventory" |
  "suppliers" |
  "purchases" |
  "material-receipts" |
  "low-stock-alert" |
  "store-dashboard" |
  "billing" |
  "ledger" |
  "expenses" |
  "payroll" |
  "attendance" |
  "shift-roster" |
  "my-payslip" |
  "workforce-reports" |
  "employee-master-and-salary" |
  "payroll-closure" |
  "verified-plant" |
  "unverified-plant" |
  "kyc-verified" |
  "pending-approval" |
  "order-enabled" |
  "restricted-access" |
  "permission-settings" |
  "warning" |
  "success";

export type TrackIconTheme = "light" | "dark";
export type TrackIconVariant = "default" | "active" | "avatar-shield" | "browser-shield" | "compact-lock";

export interface TrackIconProps {
  /** Canonical kebab-case icon identifier from the 88-icon inventory */
  name: TrackIconName;
  /** Render size in dp (React Native) or CSS px (Web). Default: 24 */
  size?: number;
  /** Theme surface adaptation ("light" uses Mirage #16232A strokes; "dark" uses Wild Sand #E4EEF0 strokes) */
  theme?: TrackIconTheme;
  /** Optional variant for bottom navigation ("active") or Restricted Access ("avatar-shield" | "browser-shield" | "compact-lock") */
  variant?: TrackIconVariant;
  /** Accessible label override (defaults to canonical action label) */
  accessibilityLabel?: string;
  /** Optional CSS className for web rendering */
  className?: string;
}

export interface TrackIconMetadata {
  name: TrackIconName;
  title: string;
  group: string;
  componentName: string;
  accessibilityLabel: string;
  svg: {
    standard: { light: string; dark: string };
    compact: { light: string; dark: string };
    active?: { light: string; dark: string };
    variants?: Record<string, { light: string; dark: string }>;
  };
}

export const TRACK_ICON_SIZES = [16, 18, 20, 24, 28, 32, 40, 48, 64, 128, 256] as const;

export const TRACK_ICON_REGISTRY: Record<TrackIconName, TrackIconMetadata> = {
  "home": {
    "name": "home",
    "title": "Home",
    "group": "Navigation and General",
    "componentName": "HomeIcon",
    "accessibilityLabel": "Navigate to Home dashboard",
    "svg": {
      "standard": {
        "light": "<path d=\"M 8 30 L 32 10 L 56 30\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 14 26 V 52 C 14 54.2 15.8 56 18 56 H 38 M 44 56 H 46 C 48.2 56 50 54.2 50 52 V 26\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 26 56 V 39 C 26 37.3 27.3 36 29 36 H 35 C 36.7 36 38 37.3 38 39 V 56\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 8 30 L 32 10 L 56 30\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 14 26 V 52 C 14 54.2 15.8 56 18 56 H 38 M 44 56 H 46 C 48.2 56 50 54.2 50 52 V 26\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 26 56 V 39 C 26 37.3 27.3 36 29 36 H 35 C 36.7 36 38 37.3 38 39 V 56\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 8 30 L 32 10 L 56 30\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 14 26 V 52 C 14 54.2 15.8 56 18 56 H 38 M 44 56 H 46 C 48.2 56 50 54.2 50 52 V 26\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 26 56 V 39 C 26 37.3 27.3 36 29 36 H 35 C 36.7 36 38 37.3 38 39 V 56\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 8 30 L 32 10 L 56 30\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 14 26 V 52 C 14 54.2 15.8 56 18 56 H 38 M 44 56 H 46 C 48.2 56 50 54.2 50 52 V 26\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 26 56 V 39 C 26 37.3 27.3 36 29 36 H 35 C 36.7 36 38 37.3 38 39 V 56\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/>"
      },
      "active": {
        "light": "<path d=\"M 10 28 L 32 10 L 54 28 V 52 C 54 54.2 52.2 56 50 56 H 38 V 39 C 38 37.3 36.7 36 35 36 H 29 C 27.3 36 26 37.3 26 39 V 56 H 14 C 11.8 56 10 54.2 10 52 Z\" fill=\"#16232A\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 10 28 L 32 10 L 54 28 V 52 C 54 54.2 52.2 56 50 56 H 38 V 39 C 38 37.3 36.7 36 35 36 H 29 C 27.3 36 26 37.3 26 39 V 56 H 14 C 11.8 56 10 54.2 10 52 Z\" fill=\"#E4EEF0\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "orders": {
    "name": "orders",
    "title": "Orders",
    "group": "Navigation and General",
    "componentName": "OrdersIcon",
    "accessibilityLabel": "View and manage concrete orders",
    "svg": {
      "standard": {
        "light": "<path d=\"M 22 12 H 16 C 13.8 12 12 13.8 12 16 V 50 C 12 52.2 13.8 54 16 54 H 34 M 41 54 H 48 C 50.2 54 52 52.2 52 50 V 16 C 52 13.8 50.2 12 48 12 H 42\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect x=\"22\" y=\"8\" width=\"20\" height=\"9\" rx=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 21 27 H 43 M 21 36 H 37 M 21 45 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 22 12 H 16 C 13.8 12 12 13.8 12 16 V 50 C 12 52.2 13.8 54 16 54 H 34 M 41 54 H 48 C 50.2 54 52 52.2 52 50 V 16 C 52 13.8 50.2 12 48 12 H 42\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect x=\"22\" y=\"8\" width=\"20\" height=\"9\" rx=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 21 27 H 43 M 21 36 H 37 M 21 45 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 22 12 H 16 C 13.8 12 12 13.8 12 16 V 50 C 12 52.2 13.8 54 16 54 H 34 M 41 54 H 48 C 50.2 54 52 52.2 52 50 V 16 C 52 13.8 50.2 12 48 12 H 42\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect x=\"22\" y=\"8\" width=\"20\" height=\"9\" rx=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 21 27 H 43 M 21 36 H 37 M 21 45 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 22 12 H 16 C 13.8 12 12 13.8 12 16 V 50 C 12 52.2 13.8 54 16 54 H 34 M 41 54 H 48 C 50.2 54 52 52.2 52 50 V 16 C 52 13.8 50.2 12 48 12 H 42\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect x=\"22\" y=\"8\" width=\"20\" height=\"9\" rx=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 21 27 H 43 M 21 36 H 37 M 21 45 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>"
      },
      "active": {
        "light": "<rect x=\"12\" y=\"12\" width=\"40\" height=\"44\" rx=\"6\" fill=\"#16232A\" stroke=\"#16232A\" stroke-width=\"3.6\"/><rect x=\"22\" y=\"7\" width=\"20\" height=\"10\" rx=\"4\" fill=\"#E4EEF0\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 21 28 H 43 M 21 37 H 37 M 21 46 H 31\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>",
        "dark": "<rect x=\"12\" y=\"12\" width=\"40\" height=\"44\" rx=\"6\" fill=\"#E4EEF0\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><rect x=\"22\" y=\"7\" width=\"20\" height=\"10\" rx=\"4\" fill=\"#16232A\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 21 28 H 43 M 21 37 H 37 M 21 46 H 31\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "plants": {
    "name": "plants",
    "title": "Plants",
    "group": "Navigation and General",
    "componentName": "PlantsIcon",
    "accessibilityLabel": "Browse Ready-Mix Concrete plants",
    "svg": {
      "standard": {
        "light": "<g fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><rect x=\"30\" y=\"24\" width=\"22\" height=\"28\" rx=\"3\"/><path d=\"M 8 52 H 36 M 43 52 H 56\"/><line x1=\"16\" y1=\"26\" x2=\"22\" y2=\"26\"/><line x1=\"16\" y1=\"33\" x2=\"22\" y2=\"33\"/><rect x=\"36\" y=\"30\" width=\"10\" height=\"7\" rx=\"1.5\"/></g>",
        "dark": "<g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><rect x=\"30\" y=\"24\" width=\"22\" height=\"28\" rx=\"3\"/><path d=\"M 8 52 H 36 M 43 52 H 56\"/><line x1=\"16\" y1=\"26\" x2=\"22\" y2=\"26\"/><line x1=\"16\" y1=\"33\" x2=\"22\" y2=\"33\"/><rect x=\"36\" y=\"30\" width=\"10\" height=\"7\" rx=\"1.5\"/></g>"
      },
      "compact": {
        "light": "<g fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><rect x=\"30\" y=\"24\" width=\"22\" height=\"28\" rx=\"3\"/><path d=\"M 8 52 H 36 M 43 52 H 56\"/></g>",
        "dark": "<g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><rect x=\"30\" y=\"24\" width=\"22\" height=\"28\" rx=\"3\"/><path d=\"M 8 52 H 36 M 43 52 H 56\"/></g>"
      },
      "active": {
        "light": "<path d=\"M 12 20 C 12 14 26 14 26 20 V 46 H 12 Z\" fill=\"#16232A\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><rect x=\"30\" y=\"24\" width=\"22\" height=\"28\" rx=\"3\" fill=\"#16232A\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 26 28 L 36 18 H 46\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 8 52 H 56\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"36\" y=\"31\" width=\"10\" height=\"8\" rx=\"1.5\" fill=\"#E4EEF0\"/>",
        "dark": "<path d=\"M 12 20 C 12 14 26 14 26 20 V 46 H 12 Z\" fill=\"#E4EEF0\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><rect x=\"30\" y=\"24\" width=\"22\" height=\"28\" rx=\"3\" fill=\"#E4EEF0\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 26 28 L 36 18 H 46\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 8 52 H 56\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"36\" y=\"31\" width=\"10\" height=\"8\" rx=\"1.5\" fill=\"#16232A\"/>"
      }
    }
  },
  "more": {
    "name": "more",
    "title": "More",
    "group": "Navigation and General",
    "componentName": "MoreIcon",
    "accessibilityLabel": "Open additional modules and menu options",
    "svg": {
      "standard": {
        "light": "<rect x=\"10\" y=\"10\" width=\"18\" height=\"18\" rx=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><rect x=\"36\" y=\"10\" width=\"18\" height=\"18\" rx=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><rect x=\"10\" y=\"36\" width=\"18\" height=\"18\" rx=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><circle cx=\"45\" cy=\"45\" r=\"9\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/>",
        "dark": "<rect x=\"10\" y=\"10\" width=\"18\" height=\"18\" rx=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><rect x=\"36\" y=\"10\" width=\"18\" height=\"18\" rx=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><rect x=\"10\" y=\"36\" width=\"18\" height=\"18\" rx=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><circle cx=\"45\" cy=\"45\" r=\"9\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/>"
      },
      "compact": {
        "light": "<rect x=\"10\" y=\"10\" width=\"18\" height=\"18\" rx=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><rect x=\"36\" y=\"10\" width=\"18\" height=\"18\" rx=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><rect x=\"10\" y=\"36\" width=\"18\" height=\"18\" rx=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><circle cx=\"45\" cy=\"45\" r=\"9\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/>",
        "dark": "<rect x=\"10\" y=\"10\" width=\"18\" height=\"18\" rx=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><rect x=\"36\" y=\"10\" width=\"18\" height=\"18\" rx=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><rect x=\"10\" y=\"36\" width=\"18\" height=\"18\" rx=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><circle cx=\"45\" cy=\"45\" r=\"9\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/>"
      },
      "active": {
        "light": "<rect x=\"10\" y=\"10\" width=\"18\" height=\"18\" rx=\"5\" fill=\"#16232A\" stroke=\"#16232A\" stroke-width=\"3.6\"/><rect x=\"36\" y=\"10\" width=\"18\" height=\"18\" rx=\"5\" fill=\"#16232A\" stroke=\"#16232A\" stroke-width=\"3.6\"/><rect x=\"10\" y=\"36\" width=\"18\" height=\"18\" rx=\"5\" fill=\"#16232A\" stroke=\"#16232A\" stroke-width=\"3.6\"/><circle cx=\"45\" cy=\"45\" r=\"9\" fill=\"#16232A\" stroke=\"#16232A\" stroke-width=\"3.6\"/>",
        "dark": "<rect x=\"10\" y=\"10\" width=\"18\" height=\"18\" rx=\"5\" fill=\"#E4EEF0\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><rect x=\"36\" y=\"10\" width=\"18\" height=\"18\" rx=\"5\" fill=\"#E4EEF0\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><rect x=\"10\" y=\"36\" width=\"18\" height=\"18\" rx=\"5\" fill=\"#E4EEF0\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><circle cx=\"45\" cy=\"45\" r=\"9\" fill=\"#E4EEF0\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/>"
      }
    }
  },
  "back": {
    "name": "back",
    "title": "Back",
    "group": "Navigation and General",
    "componentName": "BackIcon",
    "accessibilityLabel": "Go back to previous screen",
    "svg": {
      "standard": {
        "light": "<path d=\"M 36 14 L 16 32 L 36 50\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 18 32 H 44 M 50 32 H 54\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 36 14 L 16 32 L 36 50\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 18 32 H 44 M 50 32 H 54\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 36 14 L 16 32 L 36 50\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 18 32 H 44 M 50 32 H 54\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 36 14 L 16 32 L 36 50\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 18 32 H 44 M 50 32 H 54\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "search": {
    "name": "search",
    "title": "Search",
    "group": "Navigation and General",
    "componentName": "SearchIcon",
    "accessibilityLabel": "Search orders, plants, or records",
    "svg": {
      "standard": {
        "light": "<circle cx=\"28\" cy=\"28\" r=\"16\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 40 40 L 54 54\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 21 22 A 9 9 0 0 1 33 20\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<circle cx=\"28\" cy=\"28\" r=\"16\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 40 40 L 54 54\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 21 22 A 9 9 0 0 1 33 20\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<circle cx=\"28\" cy=\"28\" r=\"16\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 40 40 L 54 54\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>",
        "dark": "<circle cx=\"28\" cy=\"28\" r=\"16\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 40 40 L 54 54\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "filter": {
    "name": "filter",
    "title": "Filter",
    "group": "Navigation and General",
    "componentName": "FilterIcon",
    "accessibilityLabel": "Filter list results",
    "svg": {
      "standard": {
        "light": "<path d=\"M 10 14 H 54 L 37 33 V 48 L 27 53 V 33 L 14 18.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"19\" y1=\"21\" x2=\"45\" y2=\"21\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 10 14 H 54 L 37 33 V 48 L 27 53 V 33 L 14 18.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"19\" y1=\"21\" x2=\"45\" y2=\"21\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 10 14 H 54 L 37 33 V 48 L 27 53 V 33 L 14 18.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 10 14 H 54 L 37 33 V 48 L 27 53 V 33 L 14 18.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "settings": {
    "name": "settings",
    "title": "Settings",
    "group": "Navigation and General",
    "componentName": "SettingsIcon",
    "accessibilityLabel": "Configure application settings",
    "svg": {
      "standard": {
        "light": "<path d=\"M 28 8 H 36 L 38 14 L 44 17 L 50 13 L 55 18 L 51 24 L 54 30 L 60 32 V 40 L 54 42 L 51 48 L 55 54 L 50 59 L 44 55 L 38 58 L 36 64 H 28 L 26 58 L 20 55 L 14 59 L 9 54 L 13 48 L 10 42 L 4 40 V 32 L 10 30 L 13 24 L 9 18 L 14 13 L 20 17 L 26 14 Z\" transform=\"translate(3.2, -1.5) scale(0.9)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"32\" r=\"9\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/>",
        "dark": "<path d=\"M 28 8 H 36 L 38 14 L 44 17 L 50 13 L 55 18 L 51 24 L 54 30 L 60 32 V 40 L 54 42 L 51 48 L 55 54 L 50 59 L 44 55 L 38 58 L 36 64 H 28 L 26 58 L 20 55 L 14 59 L 9 54 L 13 48 L 10 42 L 4 40 V 32 L 10 30 L 13 24 L 9 18 L 14 13 L 20 17 L 26 14 Z\" transform=\"translate(3.2, -1.5) scale(0.9)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"32\" r=\"9\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/>"
      },
      "compact": {
        "light": "<path d=\"M 28 8 H 36 L 38 14 L 44 17 L 50 13 L 55 18 L 51 24 L 54 30 L 60 32 V 40 L 54 42 L 51 48 L 55 54 L 50 59 L 44 55 L 38 58 L 36 64 H 28 L 26 58 L 20 55 L 14 59 L 9 54 L 13 48 L 10 42 L 4 40 V 32 L 10 30 L 13 24 L 9 18 L 14 13 L 20 17 L 26 14 Z\" transform=\"translate(3.2, -1.5) scale(0.9)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"32\" r=\"9\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/>",
        "dark": "<path d=\"M 28 8 H 36 L 38 14 L 44 17 L 50 13 L 55 18 L 51 24 L 54 30 L 60 32 V 40 L 54 42 L 51 48 L 55 54 L 50 59 L 44 55 L 38 58 L 36 64 H 28 L 26 58 L 20 55 L 14 59 L 9 54 L 13 48 L 10 42 L 4 40 V 32 L 10 30 L 13 24 L 9 18 L 14 13 L 20 17 L 26 14 Z\" transform=\"translate(3.2, -1.5) scale(0.9)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"32\" r=\"9\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/>"
      }
    }
  },
  "notifications": {
    "name": "notifications",
    "title": "Notifications",
    "group": "Navigation and General",
    "componentName": "NotificationsIcon",
    "accessibilityLabel": "View alerts and notifications",
    "svg": {
      "standard": {
        "light": "<path d=\"M 38 14.5 C 36.2 13 34.2 12 32 12 C 24 12 18 18.5 18 27 V 38 L 12 45 H 52 L 46 38 V 27\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 26 46 A 6 6 0 0 0 38 46\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 32 8 V 12\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"18\" r=\"5.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/>",
        "dark": "<path d=\"M 38 14.5 C 36.2 13 34.2 12 32 12 C 24 12 18 18.5 18 27 V 38 L 12 45 H 52 L 46 38 V 27\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 26 46 A 6 6 0 0 0 38 46\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 32 8 V 12\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"18\" r=\"5.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/>"
      },
      "compact": {
        "light": "<path d=\"M 38 14.5 C 36.2 13 34.2 12 32 12 C 24 12 18 18.5 18 27 V 38 L 12 45 H 52 L 46 38 V 27\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 26 46 A 6 6 0 0 0 38 46\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 32 8 V 12\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"18\" r=\"5.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/>",
        "dark": "<path d=\"M 38 14.5 C 36.2 13 34.2 12 32 12 C 24 12 18 18.5 18 27 V 38 L 12 45 H 52 L 46 38 V 27\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 26 46 A 6 6 0 0 0 38 46\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 32 8 V 12\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"18\" r=\"5.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/>"
      }
    }
  },
  "profile": {
    "name": "profile",
    "title": "Profile",
    "group": "Navigation and General",
    "componentName": "ProfileIcon",
    "accessibilityLabel": "Manage user profile and account",
    "svg": {
      "standard": {
        "light": "<path d=\"M 49 49 A 24 24 0 1 1 53 41\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"24\" r=\"8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 17 48 C 19 39 25 36 32 36 C 39 36 45 39 47 48\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 49 49 A 24 24 0 1 1 53 41\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"24\" r=\"8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 17 48 C 19 39 25 36 32 36 C 39 36 45 39 47 48\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 49 49 A 24 24 0 1 1 53 41\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"24\" r=\"8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 17 48 C 19 39 25 36 32 36 C 39 36 45 39 47 48\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 49 49 A 24 24 0 1 1 53 41\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"24\" r=\"8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 17 48 C 19 39 25 36 32 36 C 39 36 45 39 47 48\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "support": {
    "name": "support",
    "title": "Support",
    "group": "Navigation and General",
    "componentName": "SupportIcon",
    "accessibilityLabel": "Contact TrackMyRMC customer and technical support",
    "svg": {
      "standard": {
        "light": "<path d=\"M 14 34 V 28 C 14 18 22 10 32 10 C 42 10 50 18 50 28 V 34\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"10\" y=\"30\" width=\"8\" height=\"14\" rx=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><rect x=\"46\" y=\"30\" width=\"8\" height=\"14\" rx=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 50 44 V 48 C 50 51.3 47.3 54 44 54 H 36\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"27\" y=\"50\" width=\"9\" height=\"6\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/>",
        "dark": "<path d=\"M 14 34 V 28 C 14 18 22 10 32 10 C 42 10 50 18 50 28 V 34\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"10\" y=\"30\" width=\"8\" height=\"14\" rx=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><rect x=\"46\" y=\"30\" width=\"8\" height=\"14\" rx=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 50 44 V 48 C 50 51.3 47.3 54 44 54 H 36\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"27\" y=\"50\" width=\"9\" height=\"6\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/>"
      },
      "compact": {
        "light": "<path d=\"M 14 34 V 28 C 14 18 22 10 32 10 C 42 10 50 18 50 28 V 34\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"10\" y=\"30\" width=\"8\" height=\"14\" rx=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><rect x=\"46\" y=\"30\" width=\"8\" height=\"14\" rx=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 50 44 V 48 C 50 51.3 47.3 54 44 54 H 36\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"27\" y=\"50\" width=\"9\" height=\"6\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/>",
        "dark": "<path d=\"M 14 34 V 28 C 14 18 22 10 32 10 C 42 10 50 18 50 28 V 34\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"10\" y=\"30\" width=\"8\" height=\"14\" rx=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><rect x=\"46\" y=\"30\" width=\"8\" height=\"14\" rx=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 50 44 V 48 C 50 51.3 47.3 54 44 54 H 36\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"27\" y=\"50\" width=\"9\" height=\"6\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/>"
      }
    }
  },
  "logout": {
    "name": "logout",
    "title": "Logout",
    "group": "Navigation and General",
    "componentName": "LogoutIcon",
    "accessibilityLabel": "Sign out of current session",
    "svg": {
      "standard": {
        "light": "<path d=\"M 34 12 H 18 C 14.7 12 12 14.7 12 18 V 46 C 12 49.3 14.7 52 18 52 H 34\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 26 32 H 54\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 44 22 L 54 32 L 44 42\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 34 12 H 18 C 14.7 12 12 14.7 12 18 V 46 C 12 49.3 14.7 52 18 52 H 34\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 26 32 H 54\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 44 22 L 54 32 L 44 42\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 34 12 H 18 C 14.7 12 12 14.7 12 18 V 46 C 12 49.3 14.7 52 18 52 H 34\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 26 32 H 54\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 44 22 L 54 32 L 44 42\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 34 12 H 18 C 14.7 12 12 14.7 12 18 V 46 C 12 49.3 14.7 52 18 52 H 34\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 26 32 H 54\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 44 22 L 54 32 L 44 42\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "new-order": {
    "name": "new-order",
    "title": "New Order",
    "group": "Customer",
    "componentName": "NewOrderIcon",
    "accessibilityLabel": "Place a new Ready-Mix Concrete order",
    "svg": {
      "standard": {
        "light": "<g transform=\"translate(4,12) scale(0.88)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 16 7 L 22 25 M 24 7 L 29 24\"/><path d=\"M 3 10 L 9 12 L 7 18\"/><path d=\"M 36 13 H 46 L 50 19\"/><path d=\"M 4 29 H 8 M 20 29 H 35\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/></g><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 47 40.8 V 49.2 M 42.8 45 H 51.2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>",
        "dark": "<g transform=\"translate(4,12) scale(0.88)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 16 7 L 22 25 M 24 7 L 29 24\"/><path d=\"M 3 10 L 9 12 L 7 18\"/><path d=\"M 36 13 H 46 L 50 19\"/><path d=\"M 4 29 H 8 M 20 29 H 35\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/></g><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 47 40.8 V 49.2 M 42.8 45 H 51.2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<g transform=\"translate(4,12) scale(0.88)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 50 19\"/><path d=\"M 4 29 H 8 M 20 29 H 35\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/></g><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 47 40.8 V 49.2 M 42.8 45 H 51.2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>",
        "dark": "<g transform=\"translate(4,12) scale(0.88)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 50 19\"/><path d=\"M 4 29 H 8 M 20 29 H 35\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/></g><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 47 40.8 V 49.2 M 42.8 45 H 51.2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "nearby-rmc-plants": {
    "name": "nearby-rmc-plants",
    "title": "Nearby RMC Plants",
    "group": "Customer",
    "componentName": "NearbyRmcPlantsIcon",
    "accessibilityLabel": "Discover nearby RMC batching plants on map",
    "svg": {
      "standard": {
        "light": "<path d=\"M 20 49 C 14.5 50.2 12 52 12 53.5 C 12 56 21 58 32 58 C 43 58 52 56 52 53.5 C 52 52 49.5 50.2 44 49\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 32 50 C 32 50 14 35 14 23 C 14 13 22 6 32 6 C 42 6 50 13 50 23 C 50 35 32 50 32 50 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 25 29 V 18 C 25 15 33 15 33 18 V 29 M 33 22 H 39 V 29\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 20 49 C 14.5 50.2 12 52 12 53.5 C 12 56 21 58 32 58 C 43 58 52 56 52 53.5 C 52 52 49.5 50.2 44 49\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 32 50 C 32 50 14 35 14 23 C 14 13 22 6 32 6 C 42 6 50 13 50 23 C 50 35 32 50 32 50 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 25 29 V 18 C 25 15 33 15 33 18 V 29 M 33 22 H 39 V 29\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 20 49 C 14.5 50.2 12 52 12 53.5 C 12 56 21 58 32 58 C 43 58 52 56 52 53.5 C 52 52 49.5 50.2 44 49\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 32 50 C 32 50 14 35 14 23 C 14 13 22 6 32 6 C 42 6 50 13 50 23 C 50 35 32 50 32 50 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 25 29 V 18 C 25 15 33 15 33 18 V 29 M 33 22 H 39 V 29\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 20 49 C 14.5 50.2 12 52 12 53.5 C 12 56 21 58 32 58 C 43 58 52 56 52 53.5 C 52 52 49.5 50.2 44 49\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 32 50 C 32 50 14 35 14 23 C 14 13 22 6 32 6 C 42 6 50 13 50 23 C 50 35 32 50 32 50 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 25 29 V 18 C 25 15 33 15 33 18 V 29 M 33 22 H 39 V 29\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "live-order-tracking": {
    "name": "live-order-tracking",
    "title": "Live Order Tracking",
    "group": "Customer",
    "componentName": "LiveOrderTrackingIcon",
    "accessibilityLabel": "Track transit mixer live GPS delivery status",
    "svg": {
      "standard": {
        "light": "<path d=\"M 10 52 C 18 52 22 44 34 44 H 42\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-dasharray=\"5 6\"/><g transform=\"translate(4,8) scale(0.8)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 16 7 L 22 25 M 24 7 L 29 24\"/><path d=\"M 3 10 L 9 12 L 7 18\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g><circle cx=\"50\" cy=\"46\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 45 10 A 11 11 0 0 1 56 21 M 45 16 A 5 5 0 0 1 50 21\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 10 52 C 18 52 22 44 34 44 H 42\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-dasharray=\"5 6\"/><g transform=\"translate(4,8) scale(0.8)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 16 7 L 22 25 M 24 7 L 29 24\"/><path d=\"M 3 10 L 9 12 L 7 18\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g><circle cx=\"50\" cy=\"46\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 45 10 A 11 11 0 0 1 56 21 M 45 16 A 5 5 0 0 1 50 21\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 10 52 C 18 52 22 44 34 44 H 42\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-dasharray=\"5 6\"/><g transform=\"translate(4,8) scale(0.8)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g><circle cx=\"50\" cy=\"46\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 45 10 A 11 11 0 0 1 56 21 M 45 16 A 5 5 0 0 1 50 21\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 10 52 C 18 52 22 44 34 44 H 42\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-dasharray=\"5 6\"/><g transform=\"translate(4,8) scale(0.8)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g><circle cx=\"50\" cy=\"46\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 45 10 A 11 11 0 0 1 56 21 M 45 16 A 5 5 0 0 1 50 21\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "my-orders": {
    "name": "my-orders",
    "title": "My Orders",
    "group": "Customer",
    "componentName": "MyOrdersIcon",
    "accessibilityLabel": "View customer order history and active dispatches",
    "svg": {
      "standard": {
        "light": "<path d=\"M 33 54 H 16 C 13.8 54 12 52.2 12 50 V 14 C 12 11.8 13.8 10 16 10 H 44 C 46.2 10 48 11.8 48 14 V 28\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 20 22 H 40 M 20 31 H 34 M 20 40 H 28\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><g fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 46 34.5 L 54.230000000000004 39.25 L 54.230000000000004 48.75 L 46 53.5 L 37.769999999999996 48.75 L 37.769999999999996 39.25 Z\"/><path d=\"M 37.769999999999996 39.25 L 46 44 L 54.230000000000004 39.25 M 46 44 V 53.5\"/></g>",
        "dark": "<path d=\"M 33 54 H 16 C 13.8 54 12 52.2 12 50 V 14 C 12 11.8 13.8 10 16 10 H 44 C 46.2 10 48 11.8 48 14 V 28\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 20 22 H 40 M 20 31 H 34 M 20 40 H 28\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 46 34.5 L 54.230000000000004 39.25 L 54.230000000000004 48.75 L 46 53.5 L 37.769999999999996 48.75 L 37.769999999999996 39.25 Z\"/><path d=\"M 37.769999999999996 39.25 L 46 44 L 54.230000000000004 39.25 M 46 44 V 53.5\"/></g>"
      },
      "compact": {
        "light": "<path d=\"M 33 54 H 16 C 13.8 54 12 52.2 12 50 V 14 C 12 11.8 13.8 10 16 10 H 44 C 46.2 10 48 11.8 48 14 V 28\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 20 22 H 40 M 20 31 H 34 M 20 40 H 28\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><g fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 46 34.5 L 54.230000000000004 39.25 L 54.230000000000004 48.75 L 46 53.5 L 37.769999999999996 48.75 L 37.769999999999996 39.25 Z\"/><path d=\"M 37.769999999999996 39.25 L 46 44 L 54.230000000000004 39.25 M 46 44 V 53.5\"/></g>",
        "dark": "<path d=\"M 33 54 H 16 C 13.8 54 12 52.2 12 50 V 14 C 12 11.8 13.8 10 16 10 H 44 C 46.2 10 48 11.8 48 14 V 28\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 20 22 H 40 M 20 31 H 34 M 20 40 H 28\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 46 34.5 L 54.230000000000004 39.25 L 54.230000000000004 48.75 L 46 53.5 L 37.769999999999996 48.75 L 37.769999999999996 39.25 Z\"/><path d=\"M 37.769999999999996 39.25 L 46 44 L 54.230000000000004 39.25 M 46 44 V 53.5\"/></g>"
      }
    }
  },
  "quotations": {
    "name": "quotations",
    "title": "Quotations",
    "group": "Customer",
    "componentName": "QuotationsIcon",
    "accessibilityLabel": "Review and approve price quotations",
    "svg": {
      "standard": {
        "light": "<path d=\"M 33 54 H 14 C 11.8 54 10 52.2 10 50 V 14 C 10 11.8 11.8 10 14 10 H 36 L 46 20 V 30\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 35 10 V 20 H 46\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/><path d=\"M 20 24 H 32 M 20 30 H 29 M 24 24 C 30 24 30 32 23 32 L 31 41\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"47\" cy=\"45\" r=\"10\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 42.8 45.3 L 45.8 48.5 L 51.8 41.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 33 54 H 14 C 11.8 54 10 52.2 10 50 V 14 C 10 11.8 11.8 10 14 10 H 36 L 46 20 V 30\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 35 10 V 20 H 46\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/><path d=\"M 20 24 H 32 M 20 30 H 29 M 24 24 C 30 24 30 32 23 32 L 31 41\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"47\" cy=\"45\" r=\"10\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 42.8 45.3 L 45.8 48.5 L 51.8 41.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 33 54 H 14 C 11.8 54 10 52.2 10 50 V 14 C 10 11.8 11.8 10 14 10 H 36 L 46 20 V 30\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 35 10 V 20 H 46\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/><path d=\"M 20 24 H 32 M 20 30 H 29 M 24 24 C 30 24 30 32 23 32 L 31 41\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"47\" cy=\"45\" r=\"10\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 42.8 45.3 L 45.8 48.5 L 51.8 41.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 33 54 H 14 C 11.8 54 10 52.2 10 50 V 14 C 10 11.8 11.8 10 14 10 H 36 L 46 20 V 30\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 35 10 V 20 H 46\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/><path d=\"M 20 24 H 32 M 20 30 H 29 M 24 24 C 30 24 30 32 23 32 L 31 41\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"47\" cy=\"45\" r=\"10\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 42.8 45.3 L 45.8 48.5 L 51.8 41.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "project-and-site-hub": {
    "name": "project-and-site-hub",
    "title": "Project & Site Hub",
    "group": "Customer",
    "componentName": "ProjectAndSiteHubIcon",
    "accessibilityLabel": "Manage construction projects and pour sites",
    "svg": {
      "standard": {
        "light": "<path d=\"M 8 54 H 36 M 43 54 H 56\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 18 54 V 12 M 18 14 H 52 L 46 20 H 18\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"44\" y1=\"20\" x2=\"44\" y2=\"33\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><rect x=\"38\" y=\"33\" width=\"12\" height=\"8\" rx=\"2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><rect x=\"24\" y=\"34\" width=\"11\" height=\"20\" rx=\"2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/>",
        "dark": "<path d=\"M 8 54 H 36 M 43 54 H 56\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 18 54 V 12 M 18 14 H 52 L 46 20 H 18\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"44\" y1=\"20\" x2=\"44\" y2=\"33\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><rect x=\"38\" y=\"33\" width=\"12\" height=\"8\" rx=\"2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><rect x=\"24\" y=\"34\" width=\"11\" height=\"20\" rx=\"2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/>"
      },
      "compact": {
        "light": "<path d=\"M 8 54 H 36 M 43 54 H 56\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 18 54 V 12 M 18 14 H 52 L 46 20 H 18\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"44\" y1=\"20\" x2=\"44\" y2=\"33\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><rect x=\"38\" y=\"33\" width=\"12\" height=\"8\" rx=\"2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><rect x=\"24\" y=\"34\" width=\"11\" height=\"20\" rx=\"2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/>",
        "dark": "<path d=\"M 8 54 H 36 M 43 54 H 56\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 18 54 V 12 M 18 14 H 52 L 46 20 H 18\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"44\" y1=\"20\" x2=\"44\" y2=\"33\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><rect x=\"38\" y=\"33\" width=\"12\" height=\"8\" rx=\"2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><rect x=\"24\" y=\"34\" width=\"11\" height=\"20\" rx=\"2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/>"
      }
    }
  },
  "concrete-pour-planner": {
    "name": "concrete-pour-planner",
    "title": "Concrete Pour Planner",
    "group": "Customer",
    "componentName": "ConcretePourPlannerIcon",
    "accessibilityLabel": "Schedule and plan structural concrete pours",
    "svg": {
      "standard": {
        "light": "<path d=\"M 24 54 H 16 C 12.7 54 10 51.3 10 48 V 20 C 10 16.7 12.7 14 16 14 H 48 C 51.3 14 54 16.7 54 20 V 48 C 54 51.3 51.3 54 48 54 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 10 25 H 54 M 22 9 V 17 M 42 9 V 17\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 24 32 L 37 38 L 27 45 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/><path d=\"M 41 42 C 41 42 38 46 38 48 A 3 3 0 0 0 44 48 C 44 46 41 42 41 42 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 24 54 H 16 C 12.7 54 10 51.3 10 48 V 20 C 10 16.7 12.7 14 16 14 H 48 C 51.3 14 54 16.7 54 20 V 48 C 54 51.3 51.3 54 48 54 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 10 25 H 54 M 22 9 V 17 M 42 9 V 17\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 24 32 L 37 38 L 27 45 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/><path d=\"M 41 42 C 41 42 38 46 38 48 A 3 3 0 0 0 44 48 C 44 46 41 42 41 42 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 24 54 H 16 C 12.7 54 10 51.3 10 48 V 20 C 10 16.7 12.7 14 16 14 H 48 C 51.3 14 54 16.7 54 20 V 48 C 54 51.3 51.3 54 48 54 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 10 25 H 54 M 22 9 V 17 M 42 9 V 17\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 24 32 L 37 38 L 27 45 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/><path d=\"M 41 42 C 41 42 38 46 38 48 A 3 3 0 0 0 44 48 C 44 46 41 42 41 42 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 24 54 H 16 C 12.7 54 10 51.3 10 48 V 20 C 10 16.7 12.7 14 16 14 H 48 C 51.3 14 54 16.7 54 20 V 48 C 54 51.3 51.3 54 48 54 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 10 25 H 54 M 22 9 V 17 M 42 9 V 17\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 24 32 L 37 38 L 27 45 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/><path d=\"M 41 42 C 41 42 38 46 38 48 A 3 3 0 0 0 44 48 C 44 46 41 42 41 42 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "receiving-and-quality-guide": {
    "name": "receiving-and-quality-guide",
    "title": "Receiving & Quality Guide",
    "group": "Customer",
    "componentName": "ReceivingAndQualityGuideIcon",
    "accessibilityLabel": "Site receiving checklist and slump/quality verification guide",
    "svg": {
      "standard": {
        "light": "<path d=\"M 12 14 C 12 11.8 13.8 10 16 10 H 30 V 50 H 16 C 13.8 50 12 48.2 12 46 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 48 24 V 14 C 48 11.8 46.2 10 44 10 H 30 V 50 H 34\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 45 28 L 54 32 V 42 C 54 48 45 53 45 53 C 45 53 36 48 36 42 V 32 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 41.5 41.5 L 44 44 L 49 39\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 12 14 C 12 11.8 13.8 10 16 10 H 30 V 50 H 16 C 13.8 50 12 48.2 12 46 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 48 24 V 14 C 48 11.8 46.2 10 44 10 H 30 V 50 H 34\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 45 28 L 54 32 V 42 C 54 48 45 53 45 53 C 45 53 36 48 36 42 V 32 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 41.5 41.5 L 44 44 L 49 39\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 12 14 C 12 11.8 13.8 10 16 10 H 30 V 50 H 16 C 13.8 50 12 48.2 12 46 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 48 24 V 14 C 48 11.8 46.2 10 44 10 H 30 V 50 H 34\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 45 28 L 54 32 V 42 C 54 48 45 53 45 53 C 45 53 36 48 36 42 V 32 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 41.5 41.5 L 44 44 L 49 39\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 12 14 C 12 11.8 13.8 10 16 10 H 30 V 50 H 16 C 13.8 50 12 48.2 12 46 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 48 24 V 14 C 48 11.8 46.2 10 44 10 H 30 V 50 H 34\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 45 28 L 54 32 V 42 C 54 48 45 53 45 53 C 45 53 36 48 36 42 V 32 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 41.5 41.5 L 44 44 L 49 39\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "cube-test-follow-up": {
    "name": "cube-test-follow-up",
    "title": "Cube Test Follow-up",
    "group": "Customer",
    "componentName": "CubeTestFollowUpIcon",
    "accessibilityLabel": "Track single concrete cube compressive strength follow-up",
    "svg": {
      "standard": {
        "light": "<g fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 34 45 L 26 49 L 12 41 V 23 L 26 15 L 40 23 V 31\"/><path d=\"M 12 23 L 26 31 L 40 23 M 26 31 V 49\"/></g><circle cx=\"46\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 46 40.5 V 45.5 L 49.5 47.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 34 45 L 26 49 L 12 41 V 23 L 26 15 L 40 23 V 31\"/><path d=\"M 12 23 L 26 31 L 40 23 M 26 31 V 49\"/></g><circle cx=\"46\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 46 40.5 V 45.5 L 49.5 47.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<g fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 34 45 L 26 49 L 12 41 V 23 L 26 15 L 40 23 V 31\"/><path d=\"M 12 23 L 26 31 L 40 23 M 26 31 V 49\"/></g><circle cx=\"46\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 46 40.5 V 45.5 L 49.5 47.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 34 45 L 26 49 L 12 41 V 23 L 26 15 L 40 23 V 31\"/><path d=\"M 12 23 L 26 31 L 40 23 M 26 31 V 49\"/></g><circle cx=\"46\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 46 40.5 V 45.5 L 49.5 47.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "saved-sites": {
    "name": "saved-sites",
    "title": "Saved Sites",
    "group": "Customer",
    "componentName": "SavedSitesIcon",
    "accessibilityLabel": "View bookmarked construction delivery sites",
    "svg": {
      "standard": {
        "light": "<path d=\"M 16 10 H 48 C 50.2 10 52 11.8 52 14 V 54 L 32 42 L 12 54 V 14 C 12 11.8 13.8 10 16 10 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"25\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/>",
        "dark": "<path d=\"M 16 10 H 48 C 50.2 10 52 11.8 52 14 V 54 L 32 42 L 12 54 V 14 C 12 11.8 13.8 10 16 10 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"25\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/>"
      },
      "compact": {
        "light": "<path d=\"M 16 10 H 48 C 50.2 10 52 11.8 52 14 V 54 L 32 42 L 12 54 V 14 C 12 11.8 13.8 10 16 10 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"25\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/>",
        "dark": "<path d=\"M 16 10 H 48 C 50.2 10 52 11.8 52 14 V 54 L 32 42 L 12 54 V 14 C 12 11.8 13.8 10 16 10 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"25\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/>"
      }
    }
  },
  "compare-plants": {
    "name": "compare-plants",
    "title": "Compare Plants",
    "group": "Customer",
    "componentName": "ComparePlantsIcon",
    "accessibilityLabel": "Compare RMC plants by rate, distance, and verification status",
    "svg": {
      "standard": {
        "light": "<rect x=\"8\" y=\"18\" width=\"18\" height=\"32\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><rect x=\"38\" y=\"14\" width=\"18\" height=\"36\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 26 26 H 38 M 34 22 L 38 26 L 34 30\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 38 38 H 26 M 30 34 L 26 38 L 30 42\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<rect x=\"8\" y=\"18\" width=\"18\" height=\"32\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><rect x=\"38\" y=\"14\" width=\"18\" height=\"36\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 26 26 H 38 M 34 22 L 38 26 L 34 30\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 38 38 H 26 M 30 34 L 26 38 L 30 42\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<rect x=\"8\" y=\"18\" width=\"18\" height=\"32\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><rect x=\"38\" y=\"14\" width=\"18\" height=\"36\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 26 26 H 38 M 34 22 L 38 26 L 34 30\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 38 38 H 26 M 30 34 L 26 38 L 30 42\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<rect x=\"8\" y=\"18\" width=\"18\" height=\"32\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><rect x=\"38\" y=\"14\" width=\"18\" height=\"36\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 26 26 H 38 M 34 22 L 38 26 L 34 30\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 38 38 H 26 M 30 34 L 26 38 L 30 42\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "free-rmc-tools": {
    "name": "free-rmc-tools",
    "title": "Free RMC Tools",
    "group": "Customer",
    "componentName": "FreeRmcToolsIcon",
    "accessibilityLabel": "Access free concrete volume and mix estimation tools",
    "svg": {
      "standard": {
        "light": "<path d=\"M 34 48 H 14 C 11.8 48 10 46.2 10 44 V 14 C 10 11.8 11.8 10 14 10 H 34 C 36.2 10 38 11.8 38 14 V 28\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"16\" y=\"16\" width=\"16\" height=\"8\" rx=\"2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><circle cx=\"19\" cy=\"31\" r=\"1.8\" fill=\"#16232A\"/><circle cx=\"29\" cy=\"31\" r=\"1.8\" fill=\"#16232A\"/><circle cx=\"19\" cy=\"39\" r=\"1.8\" fill=\"#16232A\"/><circle cx=\"29\" cy=\"39\" r=\"1.8\" fill=\"#16232A\"/><path d=\"M 38 30 L 52 44 C 54 46 54 49 52 51 C 50 53 47 53 45 51 L 31 37 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 34 48 H 14 C 11.8 48 10 46.2 10 44 V 14 C 10 11.8 11.8 10 14 10 H 34 C 36.2 10 38 11.8 38 14 V 28\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"16\" y=\"16\" width=\"16\" height=\"8\" rx=\"2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><circle cx=\"19\" cy=\"31\" r=\"1.8\" fill=\"#E4EEF0\"/><circle cx=\"29\" cy=\"31\" r=\"1.8\" fill=\"#E4EEF0\"/><circle cx=\"19\" cy=\"39\" r=\"1.8\" fill=\"#E4EEF0\"/><circle cx=\"29\" cy=\"39\" r=\"1.8\" fill=\"#E4EEF0\"/><path d=\"M 38 30 L 52 44 C 54 46 54 49 52 51 C 50 53 47 53 45 51 L 31 37 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 34 48 H 14 C 11.8 48 10 46.2 10 44 V 14 C 10 11.8 11.8 10 14 10 H 34 C 36.2 10 38 11.8 38 14 V 28\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"16\" y=\"16\" width=\"16\" height=\"8\" rx=\"2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><circle cx=\"19\" cy=\"31\" r=\"1.8\" fill=\"#16232A\"/><circle cx=\"29\" cy=\"31\" r=\"1.8\" fill=\"#16232A\"/><circle cx=\"19\" cy=\"39\" r=\"1.8\" fill=\"#16232A\"/><circle cx=\"29\" cy=\"39\" r=\"1.8\" fill=\"#16232A\"/><path d=\"M 38 30 L 52 44 C 54 46 54 49 52 51 C 50 53 47 53 45 51 L 31 37 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 34 48 H 14 C 11.8 48 10 46.2 10 44 V 14 C 10 11.8 11.8 10 14 10 H 34 C 36.2 10 38 11.8 38 14 V 28\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"16\" y=\"16\" width=\"16\" height=\"8\" rx=\"2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><circle cx=\"19\" cy=\"31\" r=\"1.8\" fill=\"#E4EEF0\"/><circle cx=\"29\" cy=\"31\" r=\"1.8\" fill=\"#E4EEF0\"/><circle cx=\"19\" cy=\"39\" r=\"1.8\" fill=\"#E4EEF0\"/><circle cx=\"29\" cy=\"39\" r=\"1.8\" fill=\"#E4EEF0\"/><path d=\"M 38 30 L 52 44 C 54 46 54 49 52 51 C 50 53 47 53 45 51 L 31 37 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "documents": {
    "name": "documents",
    "title": "Documents",
    "group": "Customer",
    "componentName": "DocumentsIcon",
    "accessibilityLabel": "Access invoices, test certificates, and compliance documents",
    "svg": {
      "standard": {
        "light": "<path d=\"M 26 56 H 18 C 15.8 56 14 54.2 14 52 V 16 C 14 13.8 15.8 12 18 12 H 39 L 50 23 V 52 C 50 54.2 48.2 56 46 56 H 33\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 39 12 V 23 H 50\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 22 32 H 42 M 22 40 H 38 M 22 48 H 32\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 26 56 H 18 C 15.8 56 14 54.2 14 52 V 16 C 14 13.8 15.8 12 18 12 H 39 L 50 23 V 52 C 50 54.2 48.2 56 46 56 H 33\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 39 12 V 23 H 50\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 22 32 H 42 M 22 40 H 38 M 22 48 H 32\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 26 56 H 18 C 15.8 56 14 54.2 14 52 V 16 C 14 13.8 15.8 12 18 12 H 39 L 50 23 V 52 C 50 54.2 48.2 56 46 56 H 33\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 39 12 V 23 H 50\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 22 32 H 42 M 22 40 H 38 M 22 48 H 32\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 26 56 H 18 C 15.8 56 14 54.2 14 52 V 16 C 14 13.8 15.8 12 18 12 H 39 L 50 23 V 52 C 50 54.2 48.2 56 46 56 H 33\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 39 12 V 23 H 50\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 22 32 H 42 M 22 40 H 38 M 22 48 H 32\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "kyc-verification": {
    "name": "kyc-verification",
    "title": "KYC Verification",
    "group": "Customer",
    "componentName": "KycVerificationIcon",
    "accessibilityLabel": "Submit identity and business KYC verification (Pending status)",
    "svg": {
      "standard": {
        "light": "<path d=\"M 33 46 H 13 C 10.2 46 8 43.8 8 41 V 19 C 8 16.2 10.2 14 13 14 H 47 C 49.8 14 52 16.2 52 19 V 30\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"21\" cy=\"26\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><path d=\"M 14 38 C 15 33 27 33 28 38\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><path d=\"M 34 24 H 45 M 34 31 H 41\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 47 40.5 V 45.5 L 50.5 47.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 33 46 H 13 C 10.2 46 8 43.8 8 41 V 19 C 8 16.2 10.2 14 13 14 H 47 C 49.8 14 52 16.2 52 19 V 30\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"21\" cy=\"26\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><path d=\"M 14 38 C 15 33 27 33 28 38\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><path d=\"M 34 24 H 45 M 34 31 H 41\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 47 40.5 V 45.5 L 50.5 47.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 33 46 H 13 C 10.2 46 8 43.8 8 41 V 19 C 8 16.2 10.2 14 13 14 H 47 C 49.8 14 52 16.2 52 19 V 30\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"21\" cy=\"26\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><path d=\"M 14 38 C 15 33 27 33 28 38\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><path d=\"M 34 24 H 45 M 34 31 H 41\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 47 40.5 V 45.5 L 50.5 47.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 33 46 H 13 C 10.2 46 8 43.8 8 41 V 19 C 8 16.2 10.2 14 13 14 H 47 C 49.8 14 52 16.2 52 19 V 30\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"21\" cy=\"26\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><path d=\"M 14 38 C 15 33 27 33 28 38\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><path d=\"M 34 24 H 45 M 34 31 H 41\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 47 40.5 V 45.5 L 50.5 47.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "plant-dashboard": {
    "name": "plant-dashboard",
    "title": "Plant Dashboard",
    "group": "Plant Owner",
    "componentName": "PlantDashboardIcon",
    "accessibilityLabel": "View RMC plant operational KPIs and output analytics",
    "svg": {
      "standard": {
        "light": "<path d=\"M 24 54 H 14 C 10.7 54 8 51.3 8 48 V 16 C 8 12.7 10.7 10 14 10 H 50 C 53.3 10 56 12.7 56 16 V 48 C 56 51.3 53.3 54 50 54 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 18 44 V 33 M 27 44 V 25 M 37 44 V 29 M 46 44 V 20\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 18 25 L 27 18 L 37 22 L 46 14\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 24 54 H 14 C 10.7 54 8 51.3 8 48 V 16 C 8 12.7 10.7 10 14 10 H 50 C 53.3 10 56 12.7 56 16 V 48 C 56 51.3 53.3 54 50 54 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 18 44 V 33 M 27 44 V 25 M 37 44 V 29 M 46 44 V 20\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 18 25 L 27 18 L 37 22 L 46 14\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 24 54 H 14 C 10.7 54 8 51.3 8 48 V 16 C 8 12.7 10.7 10 14 10 H 50 C 53.3 10 56 12.7 56 16 V 48 C 56 51.3 53.3 54 50 54 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 18 44 V 33 M 27 44 V 25 M 37 44 V 29 M 46 44 V 20\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 18 25 L 27 18 L 37 22 L 46 14\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 24 54 H 14 C 10.7 54 8 51.3 8 48 V 16 C 8 12.7 10.7 10 14 10 H 50 C 53.3 10 56 12.7 56 16 V 48 C 56 51.3 53.3 54 50 54 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 18 44 V 33 M 27 44 V 25 M 37 44 V 29 M 46 44 V 20\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 18 25 L 27 18 L 37 22 L 46 14\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "plant-orders": {
    "name": "plant-orders",
    "title": "Plant Orders",
    "group": "Plant Owner",
    "componentName": "PlantOrdersIcon",
    "accessibilityLabel": "Manage incoming customer orders at the plant",
    "svg": {
      "standard": {
        "light": "<path d=\"M 10 22 C 10 16 24 16 24 22 V 46 H 10 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 10 46 L 14 54 H 20 L 24 46\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><rect x=\"30\" y=\"12\" width=\"24\" height=\"40\" rx=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 36 22 H 48 M 36 30 H 48 M 36 38 H 43\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 10 22 C 10 16 24 16 24 22 V 46 H 10 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 10 46 L 14 54 H 20 L 24 46\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><rect x=\"30\" y=\"12\" width=\"24\" height=\"40\" rx=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 36 22 H 48 M 36 30 H 48 M 36 38 H 43\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 10 22 C 10 16 24 16 24 22 V 46 H 10 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 10 46 L 14 54 H 20 L 24 46\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><rect x=\"30\" y=\"12\" width=\"24\" height=\"40\" rx=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 36 22 H 48 M 36 30 H 48 M 36 38 H 43\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 10 22 C 10 16 24 16 24 22 V 46 H 10 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 10 46 L 14 54 H 20 L 24 46\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><rect x=\"30\" y=\"12\" width=\"24\" height=\"40\" rx=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 36 22 H 48 M 36 30 H 48 M 36 38 H 43\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "production-and-dispatch": {
    "name": "production-and-dispatch",
    "title": "Production & Dispatch",
    "group": "Plant Owner",
    "componentName": "ProductionAndDispatchIcon",
    "accessibilityLabel": "Monitor batching plant production and mixer dispatch",
    "svg": {
      "standard": {
        "light": "<path d=\"M 10 12 H 26 L 22 25 H 14 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><g transform=\"translate(10,22) scale(0.82)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 16 7 L 22 25 M 24 7 L 29 24\"/><path d=\"M 3 10 L 9 12 L 7 18\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g><path d=\"M 34 16 H 54 M 48 11 L 54 16 L 48 21\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 10 12 H 26 L 22 25 H 14 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><g transform=\"translate(10,22) scale(0.82)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 16 7 L 22 25 M 24 7 L 29 24\"/><path d=\"M 3 10 L 9 12 L 7 18\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g><path d=\"M 34 16 H 54 M 48 11 L 54 16 L 48 21\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 10 12 H 26 L 22 25 H 14 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><g transform=\"translate(10,22) scale(0.82)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g><path d=\"M 34 16 H 54 M 48 11 L 54 16 L 48 21\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 10 12 H 26 L 22 25 H 14 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><g transform=\"translate(10,22) scale(0.82)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g><path d=\"M 34 16 H 54 M 48 11 L 54 16 L 48 21\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "billing-and-ledger": {
    "name": "billing-and-ledger",
    "title": "Billing & Ledger",
    "group": "Plant Owner",
    "componentName": "BillingAndLedgerIcon",
    "accessibilityLabel": "Manage customer billing and financial account ledgers",
    "svg": {
      "standard": {
        "light": "<path d=\"M 29 54 H 14 C 11.8 54 10 52.2 10 50 V 14 C 10 11.8 11.8 10 14 10 H 38 C 40.2 10 42 11.8 42 14 V 25\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 18 20 H 34 M 18 28 H 30 M 18 36 H 26\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"44\" cy=\"41\" r=\"12\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 40 36 H 48 M 40 40 H 46 M 42 36 C 46 36 46 42 41 42 L 47 48\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 29 54 H 14 C 11.8 54 10 52.2 10 50 V 14 C 10 11.8 11.8 10 14 10 H 38 C 40.2 10 42 11.8 42 14 V 25\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 18 20 H 34 M 18 28 H 30 M 18 36 H 26\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"44\" cy=\"41\" r=\"12\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 40 36 H 48 M 40 40 H 46 M 42 36 C 46 36 46 42 41 42 L 47 48\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 29 54 H 14 C 11.8 54 10 52.2 10 50 V 14 C 10 11.8 11.8 10 14 10 H 38 C 40.2 10 42 11.8 42 14 V 25\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 18 20 H 34 M 18 28 H 30 M 18 36 H 26\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"44\" cy=\"41\" r=\"12\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 40 36 H 48 M 40 40 H 46 M 42 36 C 46 36 46 42 41 42 L 47 48\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 29 54 H 14 C 11.8 54 10 52.2 10 50 V 14 C 10 11.8 11.8 10 14 10 H 38 C 40.2 10 42 11.8 42 14 V 25\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 18 20 H 34 M 18 28 H 30 M 18 36 H 26\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"44\" cy=\"41\" r=\"12\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 40 36 H 48 M 40 40 H 46 M 42 36 C 46 36 46 42 41 42 L 47 48\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "billing-history": {
    "name": "billing-history",
    "title": "Billing History",
    "group": "Plant Owner",
    "componentName": "BillingHistoryIcon",
    "accessibilityLabel": "Inspect historical invoices and payment settlements",
    "svg": {
      "standard": {
        "light": "<path d=\"M 14 26 A 18 18 0 1 1 20 46\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 8 24 L 14 28 L 19 21\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 27 24 H 37 M 27 29 H 35 M 29 24 C 34 24 34 31 28 31 L 36 39\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 14 26 A 18 18 0 1 1 20 46\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 8 24 L 14 28 L 19 21\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 27 24 H 37 M 27 29 H 35 M 29 24 C 34 24 34 31 28 31 L 36 39\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 14 26 A 18 18 0 1 1 20 46\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 8 24 L 14 28 L 19 21\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 27 24 H 37 M 27 29 H 35 M 29 24 C 34 24 34 31 28 31 L 36 39\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 14 26 A 18 18 0 1 1 20 46\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 8 24 L 14 28 L 19 21\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 27 24 H 37 M 27 29 H 35 M 29 24 C 34 24 34 31 28 31 L 36 39\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "quotation-requests": {
    "name": "quotation-requests",
    "title": "Quotation Requests",
    "group": "Plant Owner",
    "componentName": "QuotationRequestsIcon",
    "accessibilityLabel": "Respond to incoming customer quotation enquiries",
    "svg": {
      "standard": {
        "light": "<path d=\"M 32 52 H 16 C 13.8 52 12 50.2 12 48 V 14 C 12 11.8 13.8 10 16 10 H 42 C 44.2 10 46 11.8 46 14 V 27\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 20 22 H 38 M 20 30 H 32\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"42\" r=\"11\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 43 38 C 43 35.5 49 35.5 49 39 C 49 41 46 41.5 46 44\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"48\" r=\"1.4\" fill=\"#16232A\"/>",
        "dark": "<path d=\"M 32 52 H 16 C 13.8 52 12 50.2 12 48 V 14 C 12 11.8 13.8 10 16 10 H 42 C 44.2 10 46 11.8 46 14 V 27\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 20 22 H 38 M 20 30 H 32\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"42\" r=\"11\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 43 38 C 43 35.5 49 35.5 49 39 C 49 41 46 41.5 46 44\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"48\" r=\"1.4\" fill=\"#E4EEF0\"/>"
      },
      "compact": {
        "light": "<path d=\"M 32 52 H 16 C 13.8 52 12 50.2 12 48 V 14 C 12 11.8 13.8 10 16 10 H 42 C 44.2 10 46 11.8 46 14 V 27\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 20 22 H 38 M 20 30 H 32\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"42\" r=\"11\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 43 38 C 43 35.5 49 35.5 49 39 C 49 41 46 41.5 46 44\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"48\" r=\"1.4\" fill=\"#16232A\"/>",
        "dark": "<path d=\"M 32 52 H 16 C 13.8 52 12 50.2 12 48 V 14 C 12 11.8 13.8 10 16 10 H 42 C 44.2 10 46 11.8 46 14 V 27\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 20 22 H 38 M 20 30 H 32\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"42\" r=\"11\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 43 38 C 43 35.5 49 35.5 49 39 C 49 41 46 41.5 46 44\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"48\" r=\"1.4\" fill=\"#E4EEF0\"/>"
      }
    }
  },
  "incident-register": {
    "name": "incident-register",
    "title": "Incident Register",
    "group": "Plant Owner",
    "componentName": "IncidentRegisterIcon",
    "accessibilityLabel": "Log and review plant safety or operational incidents",
    "svg": {
      "standard": {
        "light": "<path d=\"M 28 54 H 15 C 12.2 54 10 51.8 10 49 V 15 C 10 12.2 12.2 10 15 10 H 41 C 43.8 10 46 12.2 46 15 V 23\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 18 22 H 38 M 18 30 H 30\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><path d=\"M 44 26 L 56 48 H 32 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 44 35 V 40\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"44\" cy=\"44.2\" r=\"1.4\" fill=\"#16232A\"/>",
        "dark": "<path d=\"M 28 54 H 15 C 12.2 54 10 51.8 10 49 V 15 C 10 12.2 12.2 10 15 10 H 41 C 43.8 10 46 12.2 46 15 V 23\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 18 22 H 38 M 18 30 H 30\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><path d=\"M 44 26 L 56 48 H 32 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 44 35 V 40\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"44\" cy=\"44.2\" r=\"1.4\" fill=\"#E4EEF0\"/>"
      },
      "compact": {
        "light": "<path d=\"M 28 54 H 15 C 12.2 54 10 51.8 10 49 V 15 C 10 12.2 12.2 10 15 10 H 41 C 43.8 10 46 12.2 46 15 V 23\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 18 22 H 38 M 18 30 H 30\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><path d=\"M 44 26 L 56 48 H 32 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 44 35 V 40\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"44\" cy=\"44.2\" r=\"1.4\" fill=\"#16232A\"/>",
        "dark": "<path d=\"M 28 54 H 15 C 12.2 54 10 51.8 10 49 V 15 C 10 12.2 12.2 10 15 10 H 41 C 43.8 10 46 12.2 46 15 V 23\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 18 22 H 38 M 18 30 H 30\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><path d=\"M 44 26 L 56 48 H 32 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 44 35 V 40\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"44\" cy=\"44.2\" r=\"1.4\" fill=\"#E4EEF0\"/>"
      }
    }
  },
  "premium-and-promotions": {
    "name": "premium-and-promotions",
    "title": "Premium & Promotions",
    "group": "Plant Owner",
    "componentName": "PremiumAndPromotionsIcon",
    "accessibilityLabel": "Manage featured plant listings and promotional campaigns",
    "svg": {
      "standard": {
        "light": "<path d=\"M 10 44 L 14 20 L 25 30 L 32 14 L 39 30 L 50 20 L 54 44 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><rect x=\"12\" y=\"44\" width=\"40\" height=\"7\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/>",
        "dark": "<path d=\"M 10 44 L 14 20 L 25 30 L 32 14 L 39 30 L 50 20 L 54 44 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><rect x=\"12\" y=\"44\" width=\"40\" height=\"7\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/>"
      },
      "compact": {
        "light": "<path d=\"M 10 44 L 14 20 L 25 30 L 32 14 L 39 30 L 50 20 L 54 44 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><rect x=\"12\" y=\"44\" width=\"40\" height=\"7\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/>",
        "dark": "<path d=\"M 10 44 L 14 20 L 25 30 L 32 14 L 39 30 L 50 20 L 54 44 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><rect x=\"12\" y=\"44\" width=\"40\" height=\"7\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/>"
      }
    }
  },
  "plant-profile": {
    "name": "plant-profile",
    "title": "Plant Profile",
    "group": "Plant Owner",
    "componentName": "PlantProfileIcon",
    "accessibilityLabel": "Edit RMC plant capacity, address, and public profile",
    "svg": {
      "standard": {
        "light": "<path d=\"M 24 52 H 14 C 10.7 52 8 49.3 8 46 V 18 C 8 14.7 10.7 12 14 12 H 50 C 53.3 12 56 14.7 56 18 V 46 C 56 49.3 53.3 52 50 52 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 16 44 V 24 C 16 20 26 20 26 24 V 44 M 26 30 H 36 V 44\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 41 24 H 49 M 41 32 H 49\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 24 52 H 14 C 10.7 52 8 49.3 8 46 V 18 C 8 14.7 10.7 12 14 12 H 50 C 53.3 12 56 14.7 56 18 V 46 C 56 49.3 53.3 52 50 52 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 16 44 V 24 C 16 20 26 20 26 24 V 44 M 26 30 H 36 V 44\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 41 24 H 49 M 41 32 H 49\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 24 52 H 14 C 10.7 52 8 49.3 8 46 V 18 C 8 14.7 10.7 12 14 12 H 50 C 53.3 12 56 14.7 56 18 V 46 C 56 49.3 53.3 52 50 52 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 16 44 V 24 C 16 20 26 20 26 24 V 44 M 26 30 H 36 V 44\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 41 24 H 49 M 41 32 H 49\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 24 52 H 14 C 10.7 52 8 49.3 8 46 V 18 C 8 14.7 10.7 12 14 12 H 50 C 53.3 12 56 14.7 56 18 V 46 C 56 49.3 53.3 52 50 52 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 16 44 V 24 C 16 20 26 20 26 24 V 44 M 26 30 H 36 V 44\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 41 24 H 49 M 41 32 H 49\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "rate-cards": {
    "name": "rate-cards",
    "title": "Rate Cards",
    "group": "Plant Owner",
    "componentName": "RateCardsIcon",
    "accessibilityLabel": "Configure concrete grade pricing and rate cards",
    "svg": {
      "standard": {
        "light": "<path d=\"M 12 28 L 28 12 H 48 C 50.2 12 52 13.8 52 16 V 36 L 36 52 C 33.8 54.2 30.2 54.2 28 52 L 12 36 C 9.8 33.8 9.8 30.2 12 28 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><circle cx=\"42\" cy=\"22\" r=\"3.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><path d=\"M 24 30 H 34 M 24 35 H 32 M 26 30 C 31 30 31 37 25 37 L 32 44\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 12 28 L 28 12 H 48 C 50.2 12 52 13.8 52 16 V 36 L 36 52 C 33.8 54.2 30.2 54.2 28 52 L 12 36 C 9.8 33.8 9.8 30.2 12 28 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><circle cx=\"42\" cy=\"22\" r=\"3.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><path d=\"M 24 30 H 34 M 24 35 H 32 M 26 30 C 31 30 31 37 25 37 L 32 44\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 12 28 L 28 12 H 48 C 50.2 12 52 13.8 52 16 V 36 L 36 52 C 33.8 54.2 30.2 54.2 28 52 L 12 36 C 9.8 33.8 9.8 30.2 12 28 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><circle cx=\"42\" cy=\"22\" r=\"3.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><path d=\"M 24 30 H 34 M 24 35 H 32 M 26 30 C 31 30 31 37 25 37 L 32 44\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 12 28 L 28 12 H 48 C 50.2 12 52 13.8 52 16 V 36 L 36 52 C 33.8 54.2 30.2 54.2 28 52 L 12 36 C 9.8 33.8 9.8 30.2 12 28 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><circle cx=\"42\" cy=\"22\" r=\"3.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><path d=\"M 24 30 H 34 M 24 35 H 32 M 26 30 C 31 30 31 37 25 37 L 32 44\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "plant-reports": {
    "name": "plant-reports",
    "title": "Plant Reports",
    "group": "Plant Owner",
    "componentName": "PlantReportsIcon",
    "accessibilityLabel": "Generate daily and monthly plant performance reports",
    "svg": {
      "standard": {
        "light": "<path d=\"M 24 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 47 C 49.8 10 52 12.2 52 15 V 49 C 52 51.8 49.8 54 47 54 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"20\" y=\"34\" width=\"5\" height=\"12\" rx=\"1\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><rect x=\"29.5\" y=\"26\" width=\"5\" height=\"20\" rx=\"1\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><rect x=\"39\" y=\"19\" width=\"5\" height=\"27\" rx=\"1\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/>",
        "dark": "<path d=\"M 24 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 47 C 49.8 10 52 12.2 52 15 V 49 C 52 51.8 49.8 54 47 54 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"20\" y=\"34\" width=\"5\" height=\"12\" rx=\"1\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><rect x=\"29.5\" y=\"26\" width=\"5\" height=\"20\" rx=\"1\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><rect x=\"39\" y=\"19\" width=\"5\" height=\"27\" rx=\"1\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/>"
      },
      "compact": {
        "light": "<path d=\"M 24 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 47 C 49.8 10 52 12.2 52 15 V 49 C 52 51.8 49.8 54 47 54 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"20\" y=\"34\" width=\"5\" height=\"12\" rx=\"1\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><rect x=\"29.5\" y=\"26\" width=\"5\" height=\"20\" rx=\"1\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><rect x=\"39\" y=\"19\" width=\"5\" height=\"27\" rx=\"1\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/>",
        "dark": "<path d=\"M 24 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 47 C 49.8 10 52 12.2 52 15 V 49 C 52 51.8 49.8 54 47 54 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"20\" y=\"34\" width=\"5\" height=\"12\" rx=\"1\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><rect x=\"29.5\" y=\"26\" width=\"5\" height=\"20\" rx=\"1\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><rect x=\"39\" y=\"19\" width=\"5\" height=\"27\" rx=\"1\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/>"
      }
    }
  },
  "plant-staff": {
    "name": "plant-staff",
    "title": "Plant Staff",
    "group": "Plant Owner",
    "componentName": "PlantStaffIcon",
    "accessibilityLabel": "Manage plant workforce roles and directory",
    "svg": {
      "standard": {
        "light": "<path d=\"M 19 24 C 19 17 33 17 33 24 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><circle cx=\"26\" cy=\"29\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 12 50 C 14 40 20 38 26 38 C 32 38 38 40 40 50\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"44\" cy=\"27\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><path d=\"M 39 46 C 41 40 48 40 52 46\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 19 24 C 19 17 33 17 33 24 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><circle cx=\"26\" cy=\"29\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 12 50 C 14 40 20 38 26 38 C 32 38 38 40 40 50\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"44\" cy=\"27\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><path d=\"M 39 46 C 41 40 48 40 52 46\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 19 24 C 19 17 33 17 33 24 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><circle cx=\"26\" cy=\"29\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 12 50 C 14 40 20 38 26 38 C 32 38 38 40 40 50\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"44\" cy=\"27\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><path d=\"M 39 46 C 41 40 48 40 52 46\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 19 24 C 19 17 33 17 33 24 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><circle cx=\"26\" cy=\"29\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 12 50 C 14 40 20 38 26 38 C 32 38 38 40 40 50\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"44\" cy=\"27\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><path d=\"M 39 46 C 41 40 48 40 52 46\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "admin-dashboard": {
    "name": "admin-dashboard",
    "title": "Admin Dashboard",
    "group": "Administration and Dispatch",
    "componentName": "AdminDashboardIcon",
    "accessibilityLabel": "Open administration command center dashboard",
    "svg": {
      "standard": {
        "light": "<path d=\"M 22 46 H 13 C 10.2 46 8 43.8 8 41 V 15 C 8 12.2 10.2 10 13 10 H 51 C 53.8 10 56 12.2 56 15 V 41 C 56 43.8 53.8 46 51 46 H 29\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 24 46 L 20 54 M 40 46 L 44 54 M 16 54 H 48\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 22 34 A 10 10 0 0 1 42 34\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><line x1=\"32\" y1=\"34\" x2=\"38\" y2=\"24\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 22 46 H 13 C 10.2 46 8 43.8 8 41 V 15 C 8 12.2 10.2 10 13 10 H 51 C 53.8 10 56 12.2 56 15 V 41 C 56 43.8 53.8 46 51 46 H 29\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 24 46 L 20 54 M 40 46 L 44 54 M 16 54 H 48\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 22 34 A 10 10 0 0 1 42 34\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><line x1=\"32\" y1=\"34\" x2=\"38\" y2=\"24\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 22 46 H 13 C 10.2 46 8 43.8 8 41 V 15 C 8 12.2 10.2 10 13 10 H 51 C 53.8 10 56 12.2 56 15 V 41 C 56 43.8 53.8 46 51 46 H 29\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 24 46 L 20 54 M 40 46 L 44 54 M 16 54 H 48\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 22 34 A 10 10 0 0 1 42 34\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><line x1=\"32\" y1=\"34\" x2=\"38\" y2=\"24\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 22 46 H 13 C 10.2 46 8 43.8 8 41 V 15 C 8 12.2 10.2 10 13 10 H 51 C 53.8 10 56 12.2 56 15 V 41 C 56 43.8 53.8 46 51 46 H 29\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 24 46 L 20 54 M 40 46 L 44 54 M 16 54 H 48\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 22 34 A 10 10 0 0 1 42 34\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><line x1=\"32\" y1=\"34\" x2=\"38\" y2=\"24\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "plant-order-management": {
    "name": "plant-order-management",
    "title": "Plant Order Management",
    "group": "Administration and Dispatch",
    "componentName": "PlantOrderManagementIcon",
    "accessibilityLabel": "Supervise and route multi-plant concrete orders",
    "svg": {
      "standard": {
        "light": "<rect x=\"10\" y=\"11\" width=\"44\" height=\"11\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><rect x=\"10\" y=\"27\" width=\"44\" height=\"11\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 32 54 H 13 C 11.3 54 10 52.7 10 51 V 46 C 10 44.3 11.3 43 13 43 H 33\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"47\" r=\"9.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 41.8 47.3 L 44.8 50.5 L 50.8 43.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<rect x=\"10\" y=\"11\" width=\"44\" height=\"11\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><rect x=\"10\" y=\"27\" width=\"44\" height=\"11\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 32 54 H 13 C 11.3 54 10 52.7 10 51 V 46 C 10 44.3 11.3 43 13 43 H 33\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"47\" r=\"9.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 41.8 47.3 L 44.8 50.5 L 50.8 43.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<rect x=\"10\" y=\"11\" width=\"44\" height=\"11\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><rect x=\"10\" y=\"27\" width=\"44\" height=\"11\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 32 54 H 13 C 11.3 54 10 52.7 10 51 V 46 C 10 44.3 11.3 43 13 43 H 33\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"47\" r=\"9.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 41.8 47.3 L 44.8 50.5 L 50.8 43.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<rect x=\"10\" y=\"11\" width=\"44\" height=\"11\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><rect x=\"10\" y=\"27\" width=\"44\" height=\"11\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 32 54 H 13 C 11.3 54 10 52.7 10 51 V 46 C 10 44.3 11.3 43 13 43 H 33\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"47\" r=\"9.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 41.8 47.3 L 44.8 50.5 L 50.8 43.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "plant-onboarding-review": {
    "name": "plant-onboarding-review",
    "title": "Plant Onboarding Review",
    "group": "Administration and Dispatch",
    "componentName": "PlantOnboardingReviewIcon",
    "accessibilityLabel": "Audit and approve new RMC plant onboarding applications",
    "svg": {
      "standard": {
        "light": "<g fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><path d=\"M 30 52 V 24 H 52 V 31\"/><path d=\"M 8 52 H 34\"/></g><circle cx=\"44\" cy=\"40\" r=\"9.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 40.5 40 L 43 42.5 L 48 37.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"51\" y1=\"47\" x2=\"57\" y2=\"53\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>",
        "dark": "<g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><path d=\"M 30 52 V 24 H 52 V 31\"/><path d=\"M 8 52 H 34\"/></g><circle cx=\"44\" cy=\"40\" r=\"9.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 40.5 40 L 43 42.5 L 48 37.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"51\" y1=\"47\" x2=\"57\" y2=\"53\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<g fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><path d=\"M 30 52 V 24 H 52 V 31\"/><path d=\"M 8 52 H 34\"/></g><circle cx=\"44\" cy=\"40\" r=\"9.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 40.5 40 L 43 42.5 L 48 37.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"51\" y1=\"47\" x2=\"57\" y2=\"53\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>",
        "dark": "<g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><path d=\"M 30 52 V 24 H 52 V 31\"/><path d=\"M 8 52 H 34\"/></g><circle cx=\"44\" cy=\"40\" r=\"9.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 40.5 40 L 43 42.5 L 48 37.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"51\" y1=\"47\" x2=\"57\" y2=\"53\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "dispatch-queue": {
    "name": "dispatch-queue",
    "title": "Dispatch Queue",
    "group": "Administration and Dispatch",
    "componentName": "DispatchQueueIcon",
    "accessibilityLabel": "Manage queued transit mixer dispatches",
    "svg": {
      "standard": {
        "light": "<rect x=\"8\" y=\"11\" width=\"32\" height=\"10\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><path d=\"M 44 16 H 56 M 51 12 L 56 16 L 51 20\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(6,22) scale(0.88)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 16 7 L 22 25 M 24 7 L 29 24\"/><path d=\"M 3 10 L 9 12 L 7 18\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>",
        "dark": "<rect x=\"8\" y=\"11\" width=\"32\" height=\"10\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><path d=\"M 44 16 H 56 M 51 12 L 56 16 L 51 20\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(6,22) scale(0.88)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 16 7 L 22 25 M 24 7 L 29 24\"/><path d=\"M 3 10 L 9 12 L 7 18\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>"
      },
      "compact": {
        "light": "<rect x=\"8\" y=\"11\" width=\"32\" height=\"10\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><path d=\"M 44 16 H 56 M 51 12 L 56 16 L 51 20\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(6,22) scale(0.88)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>",
        "dark": "<rect x=\"8\" y=\"11\" width=\"32\" height=\"10\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><path d=\"M 44 16 H 56 M 51 12 L 56 16 L 51 20\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(6,22) scale(0.88)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>"
      }
    }
  },
  "fleet-availability": {
    "name": "fleet-availability",
    "title": "Fleet Availability",
    "group": "Administration and Dispatch",
    "componentName": "FleetAvailabilityIcon",
    "accessibilityLabel": "Check available and ready transit mixer trucks",
    "svg": {
      "standard": {
        "light": "<g transform=\"translate(4,12) scale(0.88)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 16 7 L 22 25 M 24 7 L 29 24\"/><path d=\"M 3 10 L 9 12 L 7 18\"/><path d=\"M 36 13 H 46 L 50 19\"/><path d=\"M 4 29 H 8 M 20 29 H 35\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/></g><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 42.8 45.3 L 45.8 48.5 L 51.8 41.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<g transform=\"translate(4,12) scale(0.88)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 16 7 L 22 25 M 24 7 L 29 24\"/><path d=\"M 3 10 L 9 12 L 7 18\"/><path d=\"M 36 13 H 46 L 50 19\"/><path d=\"M 4 29 H 8 M 20 29 H 35\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/></g><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 42.8 45.3 L 45.8 48.5 L 51.8 41.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<g transform=\"translate(4,12) scale(0.88)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 50 19\"/><path d=\"M 4 29 H 8 M 20 29 H 35\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/></g><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 42.8 45.3 L 45.8 48.5 L 51.8 41.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<g transform=\"translate(4,12) scale(0.88)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 50 19\"/><path d=\"M 4 29 H 8 M 20 29 H 35\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/></g><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 42.8 45.3 L 45.8 48.5 L 51.8 41.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "driver-assignment": {
    "name": "driver-assignment",
    "title": "Driver Assignment",
    "group": "Administration and Dispatch",
    "componentName": "DriverAssignmentIcon",
    "accessibilityLabel": "Assign transit mixer drivers to scheduled trips",
    "svg": {
      "standard": {
        "light": "<circle cx=\"22\" cy=\"22\" r=\"8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 10 44 C 12 35 17 33 22 33 C 27 33 31 34.5 33 41\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"42\" r=\"11\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><circle cx=\"45\" cy=\"42\" r=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><path d=\"M 45 31 V 39 M 35 44 L 42 42 M 55 44 L 48 42\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<circle cx=\"22\" cy=\"22\" r=\"8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 10 44 C 12 35 17 33 22 33 C 27 33 31 34.5 33 41\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"42\" r=\"11\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><circle cx=\"45\" cy=\"42\" r=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><path d=\"M 45 31 V 39 M 35 44 L 42 42 M 55 44 L 48 42\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<circle cx=\"22\" cy=\"22\" r=\"8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 10 44 C 12 35 17 33 22 33 C 27 33 31 34.5 33 41\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"42\" r=\"11\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><circle cx=\"45\" cy=\"42\" r=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><path d=\"M 45 31 V 39 M 35 44 L 42 42 M 55 44 L 48 42\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<circle cx=\"22\" cy=\"22\" r=\"8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 10 44 C 12 35 17 33 22 33 C 27 33 31 34.5 33 41\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"42\" r=\"11\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><circle cx=\"45\" cy=\"42\" r=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><path d=\"M 45 31 V 39 M 35 44 L 42 42 M 55 44 L 48 42\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "delivery-challan": {
    "name": "delivery-challan",
    "title": "Delivery Challan",
    "group": "Administration and Dispatch",
    "componentName": "DeliveryChallanIcon",
    "accessibilityLabel": "View or generate official transit mixer Delivery Challan document",
    "svg": {
      "standard": {
        "light": "<path d=\"M 14 8 H 40 L 50 18 V 54 L 45 50 L 40 54 L 35 50 L 30 54 L 25 50 L 20 54 L 14 50 V 16\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 39 8 V 19 H 50\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/><path d=\"M 21 24 H 41 M 21 31 H 36\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><rect x=\"21\" y=\"38\" width=\"16\" height=\"7\" rx=\"2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/>",
        "dark": "<path d=\"M 14 8 H 40 L 50 18 V 54 L 45 50 L 40 54 L 35 50 L 30 54 L 25 50 L 20 54 L 14 50 V 16\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 39 8 V 19 H 50\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/><path d=\"M 21 24 H 41 M 21 31 H 36\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><rect x=\"21\" y=\"38\" width=\"16\" height=\"7\" rx=\"2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/>"
      },
      "compact": {
        "light": "<path d=\"M 14 8 H 40 L 50 18 V 54 L 45 50 L 40 54 L 35 50 L 30 54 L 25 50 L 20 54 L 14 50 V 16\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 39 8 V 19 H 50\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/><path d=\"M 21 24 H 41 M 21 31 H 36\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><rect x=\"21\" y=\"38\" width=\"16\" height=\"7\" rx=\"2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/>",
        "dark": "<path d=\"M 14 8 H 40 L 50 18 V 54 L 45 50 L 40 54 L 35 50 L 30 54 L 25 50 L 20 54 L 14 50 V 16\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 39 8 V 19 H 50\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/><path d=\"M 21 24 H 41 M 21 31 H 36\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><rect x=\"21\" y=\"38\" width=\"16\" height=\"7\" rx=\"2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/>"
      }
    }
  },
  "proof-of-delivery": {
    "name": "proof-of-delivery",
    "title": "Proof of Delivery",
    "group": "Administration and Dispatch",
    "componentName": "ProofOfDeliveryIcon",
    "accessibilityLabel": "Capture digital customer signature for Proof of Delivery (ePOD)",
    "svg": {
      "standard": {
        "light": "<path d=\"M 24 54 H 16 C 12.7 54 10 51.3 10 48 V 16 C 10 12.7 12.7 10 16 10 H 48 C 51.3 10 54 12.7 54 16 V 48 C 54 51.3 51.3 54 48 54 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 16 40 C 20 30 24 44 29 34 C 33 26 36 40 44 34\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"16\" y1=\"46\" x2=\"48\" y2=\"46\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><path d=\"M 38 14 L 45 21 L 32 34 L 25 34 L 25 27 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 24 54 H 16 C 12.7 54 10 51.3 10 48 V 16 C 10 12.7 12.7 10 16 10 H 48 C 51.3 10 54 12.7 54 16 V 48 C 54 51.3 51.3 54 48 54 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 16 40 C 20 30 24 44 29 34 C 33 26 36 40 44 34\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"16\" y1=\"46\" x2=\"48\" y2=\"46\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><path d=\"M 38 14 L 45 21 L 32 34 L 25 34 L 25 27 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 24 54 H 16 C 12.7 54 10 51.3 10 48 V 16 C 10 12.7 12.7 10 16 10 H 48 C 51.3 10 54 12.7 54 16 V 48 C 54 51.3 51.3 54 48 54 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 16 40 C 20 30 24 44 29 34 C 33 26 36 40 44 34\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"16\" y1=\"46\" x2=\"48\" y2=\"46\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><path d=\"M 38 14 L 45 21 L 32 34 L 25 34 L 25 27 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 24 54 H 16 C 12.7 54 10 51.3 10 48 V 16 C 10 12.7 12.7 10 16 10 H 48 C 51.3 10 54 12.7 54 16 V 48 C 54 51.3 51.3 54 48 54 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 16 40 C 20 30 24 44 29 34 C 33 26 36 40 44 34\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"16\" y1=\"46\" x2=\"48\" y2=\"46\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><path d=\"M 38 14 L 45 21 L 32 34 L 25 34 L 25 27 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "production-queue": {
    "name": "production-queue",
    "title": "Production Queue",
    "group": "Production and Quality",
    "componentName": "ProductionQueueIcon",
    "accessibilityLabel": "Monitor active concrete batching production queue",
    "svg": {
      "standard": {
        "light": "<path d=\"M 10 42 H 54\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"16\" cy=\"48\" r=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><circle cx=\"32\" cy=\"48\" r=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><circle cx=\"48\" cy=\"48\" r=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><g fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 21 18.5 L 28.36 22.75 L 28.36 31.25 L 21 35.5 L 13.64 31.25 L 13.64 22.75 Z\"/><path d=\"M 13.64 22.75 L 21 27 L 28.36 22.75 M 21 27 V 35.5\"/></g><g fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 43 18.5 L 50.36 22.75 L 50.36 31.25 L 43 35.5 L 35.64 31.25 L 35.64 22.75 Z\"/><path d=\"M 35.64 22.75 L 43 27 L 50.36 22.75 M 43 27 V 35.5\"/></g>",
        "dark": "<path d=\"M 10 42 H 54\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"16\" cy=\"48\" r=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><circle cx=\"32\" cy=\"48\" r=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><circle cx=\"48\" cy=\"48\" r=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 21 18.5 L 28.36 22.75 L 28.36 31.25 L 21 35.5 L 13.64 31.25 L 13.64 22.75 Z\"/><path d=\"M 13.64 22.75 L 21 27 L 28.36 22.75 M 21 27 V 35.5\"/></g><g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 43 18.5 L 50.36 22.75 L 50.36 31.25 L 43 35.5 L 35.64 31.25 L 35.64 22.75 Z\"/><path d=\"M 35.64 22.75 L 43 27 L 50.36 22.75 M 43 27 V 35.5\"/></g>"
      },
      "compact": {
        "light": "<path d=\"M 10 42 H 54\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"16\" cy=\"48\" r=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><circle cx=\"32\" cy=\"48\" r=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><circle cx=\"48\" cy=\"48\" r=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><g fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 21 18.5 L 28.36 22.75 L 28.36 31.25 L 21 35.5 L 13.64 31.25 L 13.64 22.75 Z\"/><path d=\"M 13.64 22.75 L 21 27 L 28.36 22.75 M 21 27 V 35.5\"/></g><g fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 43 18.5 L 50.36 22.75 L 50.36 31.25 L 43 35.5 L 35.64 31.25 L 35.64 22.75 Z\"/><path d=\"M 35.64 22.75 L 43 27 L 50.36 22.75 M 43 27 V 35.5\"/></g>",
        "dark": "<path d=\"M 10 42 H 54\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"16\" cy=\"48\" r=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><circle cx=\"32\" cy=\"48\" r=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><circle cx=\"48\" cy=\"48\" r=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 21 18.5 L 28.36 22.75 L 28.36 31.25 L 21 35.5 L 13.64 31.25 L 13.64 22.75 Z\"/><path d=\"M 13.64 22.75 L 21 27 L 28.36 22.75 M 21 27 V 35.5\"/></g><g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 43 18.5 L 50.36 22.75 L 50.36 31.25 L 43 35.5 L 35.64 31.25 L 35.64 22.75 Z\"/><path d=\"M 35.64 22.75 L 43 27 L 50.36 22.75 M 43 27 V 35.5\"/></g>"
      }
    }
  },
  "batching-operations": {
    "name": "batching-operations",
    "title": "Batching Operations",
    "group": "Production and Quality",
    "componentName": "BatchingOperationsIcon",
    "accessibilityLabel": "Control weigh-batcher hopper and mixer operations",
    "svg": {
      "standard": {
        "light": "<path d=\"M 14 12 H 50 L 40 30 H 24 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"44\" r=\"11\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 26 44 C 29 39 35 49 38 44\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 14 12 H 50 L 40 30 H 24 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"44\" r=\"11\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 26 44 C 29 39 35 49 38 44\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 14 12 H 50 L 40 30 H 24 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"44\" r=\"11\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 26 44 C 29 39 35 49 38 44\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 14 12 H 50 L 40 30 H 24 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"44\" r=\"11\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 26 44 C 29 39 35 49 38 44\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "mix-designs": {
    "name": "mix-designs",
    "title": "Mix Designs",
    "group": "Production and Quality",
    "componentName": "MixDesignsIcon",
    "accessibilityLabel": "Manage M10-M60 concrete mix design proportions and admixtures",
    "svg": {
      "standard": {
        "light": "<path d=\"M 24 10 H 40 M 28 10 V 22 L 14 46 C 12 49.5 14.5 54 18.5 54 H 45.5 C 49.5 54 52 49.5 50 46 L 36 22 V 10\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 19 40 C 26 36 38 44 45 40\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"27\" cy=\"47\" r=\"2.2\" fill=\"#16232A\"/><circle cx=\"36\" cy=\"46\" r=\"2.2\" fill=\"#16232A\"/>",
        "dark": "<path d=\"M 24 10 H 40 M 28 10 V 22 L 14 46 C 12 49.5 14.5 54 18.5 54 H 45.5 C 49.5 54 52 49.5 50 46 L 36 22 V 10\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 19 40 C 26 36 38 44 45 40\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"27\" cy=\"47\" r=\"2.2\" fill=\"#E4EEF0\"/><circle cx=\"36\" cy=\"46\" r=\"2.2\" fill=\"#E4EEF0\"/>"
      },
      "compact": {
        "light": "<path d=\"M 24 10 H 40 M 28 10 V 22 L 14 46 C 12 49.5 14.5 54 18.5 54 H 45.5 C 49.5 54 52 49.5 50 46 L 36 22 V 10\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 19 40 C 26 36 38 44 45 40\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"27\" cy=\"47\" r=\"2.2\" fill=\"#16232A\"/><circle cx=\"36\" cy=\"46\" r=\"2.2\" fill=\"#16232A\"/>",
        "dark": "<path d=\"M 24 10 H 40 M 28 10 V 22 L 14 46 C 12 49.5 14.5 54 18.5 54 H 45.5 C 49.5 54 52 49.5 50 46 L 36 22 V 10\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 19 40 C 26 36 38 44 45 40\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"27\" cy=\"47\" r=\"2.2\" fill=\"#E4EEF0\"/><circle cx=\"36\" cy=\"46\" r=\"2.2\" fill=\"#E4EEF0\"/>"
      }
    }
  },
  "quality-register": {
    "name": "quality-register",
    "title": "Quality Register",
    "group": "Production and Quality",
    "componentName": "QualityRegisterIcon",
    "accessibilityLabel": "Record slump tests, temperature, and QA compliance logs",
    "svg": {
      "standard": {
        "light": "<path d=\"M 32 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 43 C 45.8 10 48 12.2 48 15 V 26\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 20 22 H 38 M 20 31 H 34 M 20 40 H 28\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"39\" r=\"8.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 41 46.5 L 39 55 L 45 51.5 L 51 55 L 49 46.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 32 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 43 C 45.8 10 48 12.2 48 15 V 26\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 20 22 H 38 M 20 31 H 34 M 20 40 H 28\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"39\" r=\"8.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 41 46.5 L 39 55 L 45 51.5 L 51 55 L 49 46.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 32 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 43 C 45.8 10 48 12.2 48 15 V 26\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 20 22 H 38 M 20 31 H 34 M 20 40 H 28\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"39\" r=\"8.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 41 46.5 L 39 55 L 45 51.5 L 51 55 L 49 46.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 32 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 43 C 45.8 10 48 12.2 48 15 V 26\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 20 22 H 38 M 20 31 H 34 M 20 40 H 28\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"39\" r=\"8.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 41 46.5 L 39 55 L 45 51.5 L 51 55 L 49 46.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "concrete-cube-testing": {
    "name": "concrete-cube-testing",
    "title": "Concrete Cube Testing",
    "group": "Production and Quality",
    "componentName": "ConcreteCubeTestingIcon",
    "accessibilityLabel": "Manage 7-day and 28-day three-cube laboratory compressive testing",
    "svg": {
      "standard": {
        "light": "<g fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 20 31.5 L 28.23 36.25 L 28.23 45.75 L 20 50.5 L 11.77 45.75 L 11.77 36.25 Z\"/><path d=\"M 11.77 36.25 L 20 41 L 28.23 36.25 M 20 41 V 50.5\"/></g><g fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 44 31.5 L 52.230000000000004 36.25 L 52.230000000000004 45.75 L 44 50.5 L 35.769999999999996 45.75 L 35.769999999999996 36.25 Z\"/><path d=\"M 35.769999999999996 36.25 L 44 41 L 52.230000000000004 36.25 M 44 41 V 50.5\"/></g><g fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 32 11.5 L 40.230000000000004 16.25 L 40.230000000000004 25.75 L 32 30.5 L 23.77 25.75 L 23.77 16.25 Z\"/><path d=\"M 23.77 16.25 L 32 21 L 40.230000000000004 16.25 M 32 21 V 30.5\"/></g>",
        "dark": "<g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 20 31.5 L 28.23 36.25 L 28.23 45.75 L 20 50.5 L 11.77 45.75 L 11.77 36.25 Z\"/><path d=\"M 11.77 36.25 L 20 41 L 28.23 36.25 M 20 41 V 50.5\"/></g><g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 44 31.5 L 52.230000000000004 36.25 L 52.230000000000004 45.75 L 44 50.5 L 35.769999999999996 45.75 L 35.769999999999996 36.25 Z\"/><path d=\"M 35.769999999999996 36.25 L 44 41 L 52.230000000000004 36.25 M 44 41 V 50.5\"/></g><g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 32 11.5 L 40.230000000000004 16.25 L 40.230000000000004 25.75 L 32 30.5 L 23.77 25.75 L 23.77 16.25 Z\"/><path d=\"M 23.77 16.25 L 32 21 L 40.230000000000004 16.25 M 32 21 V 30.5\"/></g>"
      },
      "compact": {
        "light": "<g fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 20 31.5 L 28.23 36.25 L 28.23 45.75 L 20 50.5 L 11.77 45.75 L 11.77 36.25 Z\"/><path d=\"M 11.77 36.25 L 20 41 L 28.23 36.25 M 20 41 V 50.5\"/></g><g fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 44 31.5 L 52.230000000000004 36.25 L 52.230000000000004 45.75 L 44 50.5 L 35.769999999999996 45.75 L 35.769999999999996 36.25 Z\"/><path d=\"M 35.769999999999996 36.25 L 44 41 L 52.230000000000004 36.25 M 44 41 V 50.5\"/></g><g fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 32 11.5 L 40.230000000000004 16.25 L 40.230000000000004 25.75 L 32 30.5 L 23.77 25.75 L 23.77 16.25 Z\"/><path d=\"M 23.77 16.25 L 32 21 L 40.230000000000004 16.25 M 32 21 V 30.5\"/></g>",
        "dark": "<g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 20 31.5 L 28.23 36.25 L 28.23 45.75 L 20 50.5 L 11.77 45.75 L 11.77 36.25 Z\"/><path d=\"M 11.77 36.25 L 20 41 L 28.23 36.25 M 20 41 V 50.5\"/></g><g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 44 31.5 L 52.230000000000004 36.25 L 52.230000000000004 45.75 L 44 50.5 L 35.769999999999996 45.75 L 35.769999999999996 36.25 Z\"/><path d=\"M 35.769999999999996 36.25 L 44 41 L 52.230000000000004 36.25 M 44 41 V 50.5\"/></g><g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 32 11.5 L 40.230000000000004 16.25 L 40.230000000000004 25.75 L 32 30.5 L 23.77 25.75 L 23.77 16.25 Z\"/><path d=\"M 23.77 16.25 L 32 21 L 40.230000000000004 16.25 M 32 21 V 30.5\"/></g>"
      }
    }
  },
  "material-consumption": {
    "name": "material-consumption",
    "title": "Material Consumption",
    "group": "Production and Quality",
    "componentName": "MaterialConsumptionIcon",
    "accessibilityLabel": "Track cement, aggregate, sand, and admixture consumption",
    "svg": {
      "standard": {
        "light": "<path d=\"M 10 46 L 24 24 L 38 46 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 31 46 H 54 L 42 28 L 35 38.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 46 10 V 23 M 41 18 L 46 23 L 51 18\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 10 46 L 24 24 L 38 46 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 31 46 H 54 L 42 28 L 35 38.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 46 10 V 23 M 41 18 L 46 23 L 51 18\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 10 46 L 24 24 L 38 46 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 31 46 H 54 L 42 28 L 35 38.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 46 10 V 23 M 41 18 L 46 23 L 51 18\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 10 46 L 24 24 L 38 46 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 31 46 H 54 L 42 28 L 35 38.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 46 10 V 23 M 41 18 L 46 23 L 51 18\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "production-report": {
    "name": "production-report",
    "title": "Production Report",
    "group": "Production and Quality",
    "componentName": "ProductionReportIcon",
    "accessibilityLabel": "View batching output efficiency and production reports",
    "svg": {
      "standard": {
        "light": "<path d=\"M 24 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 47 C 49.8 10 52 12.2 52 15 V 49 C 52 51.8 49.8 54 47 54 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"29\" cy=\"28\" r=\"10\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 29 18 V 28 H 39\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 20 45 H 44\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 24 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 47 C 49.8 10 52 12.2 52 15 V 49 C 52 51.8 49.8 54 47 54 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"29\" cy=\"28\" r=\"10\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 29 18 V 28 H 39\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 20 45 H 44\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 24 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 47 C 49.8 10 52 12.2 52 15 V 49 C 52 51.8 49.8 54 47 54 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"29\" cy=\"28\" r=\"10\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 29 18 V 28 H 39\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 20 45 H 44\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 24 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 47 C 49.8 10 52 12.2 52 15 V 49 C 52 51.8 49.8 54 47 54 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"29\" cy=\"28\" r=\"10\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 29 18 V 28 H 39\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 20 45 H 44\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "transit-mixer-fleet": {
    "name": "transit-mixer-fleet",
    "title": "Transit Mixer Fleet",
    "group": "Fleet and Driver",
    "componentName": "TransitMixerFleetIcon",
    "accessibilityLabel": "View full transit mixer vehicle fleet inventory",
    "svg": {
      "standard": {
        "light": "<path d=\"M 18 14 L 24 6 H 39 L 43 12 M 43 11 H 52 L 56 17\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(4,18) scale(0.88)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 16 7 L 22 25 M 24 7 L 29 24\"/><path d=\"M 3 10 L 9 12 L 7 18\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>",
        "dark": "<path d=\"M 18 14 L 24 6 H 39 L 43 12 M 43 11 H 52 L 56 17\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(4,18) scale(0.88)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 16 7 L 22 25 M 24 7 L 29 24\"/><path d=\"M 3 10 L 9 12 L 7 18\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>"
      },
      "compact": {
        "light": "<path d=\"M 18 14 L 24 6 H 39 L 43 12 M 43 11 H 52 L 56 17\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(4,18) scale(0.88)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>",
        "dark": "<path d=\"M 18 14 L 24 6 H 39 L 43 12 M 43 11 H 52 L 56 17\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(4,18) scale(0.88)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>"
      }
    }
  },
  "assigned-trips": {
    "name": "assigned-trips",
    "title": "Assigned Trips",
    "group": "Fleet and Driver",
    "componentName": "AssignedTripsIcon",
    "accessibilityLabel": "View driver's assigned concrete delivery trips",
    "svg": {
      "standard": {
        "light": "<circle cx=\"16\" cy=\"48\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><circle cx=\"48\" cy=\"16\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 21 48 H 34 C 39 48 39 32 32 32 C 25 32 25 16 32 16 H 42\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>",
        "dark": "<circle cx=\"16\" cy=\"48\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><circle cx=\"48\" cy=\"16\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 21 48 H 34 C 39 48 39 32 32 32 C 25 32 25 16 32 16 H 42\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<circle cx=\"16\" cy=\"48\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><circle cx=\"48\" cy=\"16\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 21 48 H 34 C 39 48 39 32 32 32 C 25 32 25 16 32 16 H 42\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>",
        "dark": "<circle cx=\"16\" cy=\"48\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><circle cx=\"48\" cy=\"16\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 21 48 H 34 C 39 48 39 32 32 32 C 25 32 25 16 32 16 H 42\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "gps-live-location": {
    "name": "gps-live-location",
    "title": "GPS Live Location",
    "group": "Fleet and Driver",
    "componentName": "GpsLiveLocationIcon",
    "accessibilityLabel": "Monitor real-time transit mixer GPS telemetry",
    "svg": {
      "standard": {
        "light": "<circle cx=\"32\" cy=\"32\" r=\"18\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><circle cx=\"32\" cy=\"32\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 32 6 V 14 M 32 50 V 58 M 6 32 H 14 M 50 32 H 58\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>",
        "dark": "<circle cx=\"32\" cy=\"32\" r=\"18\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><circle cx=\"32\" cy=\"32\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 32 6 V 14 M 32 50 V 58 M 6 32 H 14 M 50 32 H 58\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<circle cx=\"32\" cy=\"32\" r=\"18\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><circle cx=\"32\" cy=\"32\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 32 6 V 14 M 32 50 V 58 M 6 32 H 14 M 50 32 H 58\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>",
        "dark": "<circle cx=\"32\" cy=\"32\" r=\"18\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><circle cx=\"32\" cy=\"32\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 32 6 V 14 M 32 50 V 58 M 6 32 H 14 M 50 32 H 58\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "drivers": {
    "name": "drivers",
    "title": "Drivers",
    "group": "Fleet and Driver",
    "componentName": "DriversIcon",
    "accessibilityLabel": "Manage registered transit mixer drivers and licenses",
    "svg": {
      "standard": {
        "light": "<circle cx=\"32\" cy=\"21\" r=\"8.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 22 18 H 42\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"44\" r=\"12\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><circle cx=\"32\" cy=\"44\" r=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><path d=\"M 32 32 V 41 M 21 46 L 29 44 M 43 46 L 35 44\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<circle cx=\"32\" cy=\"21\" r=\"8.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 22 18 H 42\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"44\" r=\"12\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><circle cx=\"32\" cy=\"44\" r=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><path d=\"M 32 32 V 41 M 21 46 L 29 44 M 43 46 L 35 44\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<circle cx=\"32\" cy=\"21\" r=\"8.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 22 18 H 42\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"44\" r=\"12\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><circle cx=\"32\" cy=\"44\" r=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><path d=\"M 32 32 V 41 M 21 46 L 29 44 M 43 46 L 35 44\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<circle cx=\"32\" cy=\"21\" r=\"8.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 22 18 H 42\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"44\" r=\"12\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><circle cx=\"32\" cy=\"44\" r=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><path d=\"M 32 32 V 41 M 21 46 L 29 44 M 43 46 L 35 44\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "vehicle-maintenance": {
    "name": "vehicle-maintenance",
    "title": "Vehicle Maintenance",
    "group": "Fleet and Driver",
    "componentName": "VehicleMaintenanceIcon",
    "accessibilityLabel": "Log preventive and breakdown vehicle maintenance",
    "svg": {
      "standard": {
        "light": "<g transform=\"translate(4,20) scale(0.8)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g><path d=\"M 42 10 C 38 10 36 14 38 18 L 28 28 L 33 33 L 43 23 C 47 25 51 23 51 19 L 46 20 L 44 16 L 46 12 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/>",
        "dark": "<g transform=\"translate(4,20) scale(0.8)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g><path d=\"M 42 10 C 38 10 36 14 38 18 L 28 28 L 33 33 L 43 23 C 47 25 51 23 51 19 L 46 20 L 44 16 L 46 12 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<g transform=\"translate(4,20) scale(0.8)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g><path d=\"M 42 10 C 38 10 36 14 38 18 L 28 28 L 33 33 L 43 23 C 47 25 51 23 51 19 L 46 20 L 44 16 L 46 12 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/>",
        "dark": "<g transform=\"translate(4,20) scale(0.8)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g><path d=\"M 42 10 C 38 10 36 14 38 18 L 28 28 L 33 33 L 43 23 C 47 25 51 23 51 19 L 46 20 L 44 16 L 46 12 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "diesel-ledger": {
    "name": "diesel-ledger",
    "title": "Diesel Ledger",
    "group": "Fleet and Driver",
    "componentName": "DieselLedgerIcon",
    "accessibilityLabel": "Track transit mixer fuel issuance and diesel consumption ledger",
    "svg": {
      "standard": {
        "light": "<path d=\"M 20 54 H 16 C 13.8 54 12 52.2 12 50 V 18 C 12 15.8 13.8 14 16 14 H 32 C 34.2 14 36 15.8 36 18 V 50 C 36 52.2 34.2 54 32 54 H 26\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"17\" y=\"20\" width=\"14\" height=\"9\" rx=\"2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><path d=\"M 36 22 H 44 V 42 C 44 45 48 45 48 42 V 26 L 42 18\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 24 35 C 24 35 19.5 40.5 19.5 43.5 A 4.5 4.5 0 0 0 28.5 43.5 C 28.5 40.5 24 35 24 35 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 20 54 H 16 C 13.8 54 12 52.2 12 50 V 18 C 12 15.8 13.8 14 16 14 H 32 C 34.2 14 36 15.8 36 18 V 50 C 36 52.2 34.2 54 32 54 H 26\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"17\" y=\"20\" width=\"14\" height=\"9\" rx=\"2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><path d=\"M 36 22 H 44 V 42 C 44 45 48 45 48 42 V 26 L 42 18\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 24 35 C 24 35 19.5 40.5 19.5 43.5 A 4.5 4.5 0 0 0 28.5 43.5 C 28.5 40.5 24 35 24 35 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 20 54 H 16 C 13.8 54 12 52.2 12 50 V 18 C 12 15.8 13.8 14 16 14 H 32 C 34.2 14 36 15.8 36 18 V 50 C 36 52.2 34.2 54 32 54 H 26\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"17\" y=\"20\" width=\"14\" height=\"9\" rx=\"2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><path d=\"M 36 22 H 44 V 42 C 44 45 48 45 48 42 V 26 L 42 18\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 24 35 C 24 35 19.5 40.5 19.5 43.5 A 4.5 4.5 0 0 0 28.5 43.5 C 28.5 40.5 24 35 24 35 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 20 54 H 16 C 13.8 54 12 52.2 12 50 V 18 C 12 15.8 13.8 14 16 14 H 32 C 34.2 14 36 15.8 36 18 V 50 C 36 52.2 34.2 54 32 54 H 26\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"17\" y=\"20\" width=\"14\" height=\"9\" rx=\"2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><path d=\"M 36 22 H 44 V 42 C 44 45 48 45 48 42 V 26 L 42 18\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 24 35 C 24 35 19.5 40.5 19.5 43.5 A 4.5 4.5 0 0 0 28.5 43.5 C 28.5 40.5 24 35 24 35 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "driver-attendance": {
    "name": "driver-attendance",
    "title": "Driver Attendance",
    "group": "Fleet and Driver",
    "componentName": "DriverAttendanceIcon",
    "accessibilityLabel": "Record and verify transit mixer driver daily attendance",
    "svg": {
      "standard": {
        "light": "<circle cx=\"24\" cy=\"22\" r=\"8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 10 48 C 12 38 18 35 24 35 C 28.5 35 32.5 36.8 35 41.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"43\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 41.8 43.3 L 44.8 46.5 L 50.8 39.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<circle cx=\"24\" cy=\"22\" r=\"8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 10 48 C 12 38 18 35 24 35 C 28.5 35 32.5 36.8 35 41.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"43\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 41.8 43.3 L 44.8 46.5 L 50.8 39.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<circle cx=\"24\" cy=\"22\" r=\"8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 10 48 C 12 38 18 35 24 35 C 28.5 35 32.5 36.8 35 41.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"43\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 41.8 43.3 L 44.8 46.5 L 50.8 39.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<circle cx=\"24\" cy=\"22\" r=\"8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 10 48 C 12 38 18 35 24 35 C 28.5 35 32.5 36.8 35 41.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"43\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 41.8 43.3 L 44.8 46.5 L 50.8 39.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "emergency-sos": {
    "name": "emergency-sos",
    "title": "Emergency SOS",
    "group": "Fleet and Driver",
    "componentName": "EmergencySosIcon",
    "accessibilityLabel": "Trigger urgent driver or site Emergency SOS alert",
    "svg": {
      "standard": {
        "light": "<path d=\"M 22 8 H 42 L 56 22 V 42 L 42 56 H 22 L 8 42 V 22 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 32 20 V 35\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"44\" r=\"2.4\" fill=\"#16232A\"/>",
        "dark": "<path d=\"M 22 8 H 42 L 56 22 V 42 L 42 56 H 22 L 8 42 V 22 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><path d=\"M 32 20 V 35\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"44\" r=\"2.4\" fill=\"#E4EEF0\"/>"
      },
      "compact": {
        "light": "<path d=\"M 22 8 H 42 L 56 22 V 42 L 42 56 H 22 L 8 42 V 22 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 32 20 V 35\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"44\" r=\"2.4\" fill=\"#16232A\"/>",
        "dark": "<path d=\"M 22 8 H 42 L 56 22 V 42 L 42 56 H 22 L 8 42 V 22 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><path d=\"M 32 20 V 35\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"44\" r=\"2.4\" fill=\"#E4EEF0\"/>"
      }
    }
  },
  "trip-history": {
    "name": "trip-history",
    "title": "Trip History",
    "group": "Fleet and Driver",
    "componentName": "TripHistoryIcon",
    "accessibilityLabel": "Review completed transit mixer delivery trip logs",
    "svg": {
      "standard": {
        "light": "<path d=\"M 12 28 A 20 20 0 1 1 18 48\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 6 26 L 12 30 L 17 23\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(16,18) scale(0.62)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>",
        "dark": "<path d=\"M 12 28 A 20 20 0 1 1 18 48\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 6 26 L 12 30 L 17 23\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(16,18) scale(0.62)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>"
      },
      "compact": {
        "light": "<path d=\"M 12 28 A 20 20 0 1 1 18 48\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 6 26 L 12 30 L 17 23\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(16,18) scale(0.62)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>",
        "dark": "<path d=\"M 12 28 A 20 20 0 1 1 18 48\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 6 26 L 12 30 L 17 23\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(16,18) scale(0.62)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>"
      }
    }
  },
  "stock-register": {
    "name": "stock-register",
    "title": "Stock Register",
    "group": "Inventory and Store",
    "componentName": "StockRegisterIcon",
    "accessibilityLabel": "Inspect master raw material stock register",
    "svg": {
      "standard": {
        "light": "<path d=\"M 24 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 47 C 49.8 10 52 12.2 52 15 V 49 C 52 51.8 49.8 54 47 54 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><line x1=\"12\" y1=\"24\" x2=\"52\" y2=\"24\" stroke=\"#16232A\" stroke-width=\"3.0\"/><line x1=\"12\" y1=\"38\" x2=\"52\" y2=\"38\" stroke=\"#16232A\" stroke-width=\"3.0\"/><line x1=\"28\" y1=\"10\" x2=\"28\" y2=\"54\" stroke=\"#16232A\" stroke-width=\"3.0\"/>",
        "dark": "<path d=\"M 24 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 47 C 49.8 10 52 12.2 52 15 V 49 C 52 51.8 49.8 54 47 54 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><line x1=\"12\" y1=\"24\" x2=\"52\" y2=\"24\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><line x1=\"12\" y1=\"38\" x2=\"52\" y2=\"38\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><line x1=\"28\" y1=\"10\" x2=\"28\" y2=\"54\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/>"
      },
      "compact": {
        "light": "<path d=\"M 24 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 47 C 49.8 10 52 12.2 52 15 V 49 C 52 51.8 49.8 54 47 54 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><line x1=\"12\" y1=\"24\" x2=\"52\" y2=\"24\" stroke=\"#16232A\" stroke-width=\"4.0\"/><line x1=\"12\" y1=\"38\" x2=\"52\" y2=\"38\" stroke=\"#16232A\" stroke-width=\"4.0\"/><line x1=\"28\" y1=\"10\" x2=\"28\" y2=\"54\" stroke=\"#16232A\" stroke-width=\"4.0\"/>",
        "dark": "<path d=\"M 24 54 H 17 C 14.2 54 12 51.8 12 49 V 15 C 12 12.2 14.2 10 17 10 H 47 C 49.8 10 52 12.2 52 15 V 49 C 52 51.8 49.8 54 47 54 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><line x1=\"12\" y1=\"24\" x2=\"52\" y2=\"24\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><line x1=\"12\" y1=\"38\" x2=\"52\" y2=\"38\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><line x1=\"28\" y1=\"10\" x2=\"28\" y2=\"54\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/>"
      }
    }
  },
  "material-inventory": {
    "name": "material-inventory",
    "title": "Material Inventory",
    "group": "Inventory and Store",
    "componentName": "MaterialInventoryIcon",
    "accessibilityLabel": "Monitor silo cement and aggregate yard inventory levels",
    "svg": {
      "standard": {
        "light": "<path d=\"M 8 50 L 21 25 L 34 50 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><rect x=\"35\" y=\"16\" width=\"18\" height=\"34\" rx=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 39 26 H 49 M 39 34 H 49\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 8 50 L 21 25 L 34 50 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linejoin=\"round\"/><rect x=\"35\" y=\"16\" width=\"18\" height=\"34\" rx=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 39 26 H 49 M 39 34 H 49\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 8 50 L 21 25 L 34 50 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><rect x=\"35\" y=\"16\" width=\"18\" height=\"34\" rx=\"4\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 39 26 H 49 M 39 34 H 49\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 8 50 L 21 25 L 34 50 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linejoin=\"round\"/><rect x=\"35\" y=\"16\" width=\"18\" height=\"34\" rx=\"4\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 39 26 H 49 M 39 34 H 49\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "suppliers": {
    "name": "suppliers",
    "title": "Suppliers",
    "group": "Inventory and Store",
    "componentName": "SuppliersIcon",
    "accessibilityLabel": "Manage raw material vendors and transport suppliers",
    "svg": {
      "standard": {
        "light": "<path d=\"M 8 28 L 24 14 L 35 21 M 22 40 H 12 L 8 28\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(15,20) scale(0.8)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>",
        "dark": "<path d=\"M 8 28 L 24 14 L 35 21 M 22 40 H 12 L 8 28\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(15,20) scale(0.8)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>"
      },
      "compact": {
        "light": "<path d=\"M 8 28 L 24 14 L 35 21 M 22 40 H 12 L 8 28\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(15,20) scale(0.8)\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>",
        "dark": "<path d=\"M 8 28 L 24 14 L 35 21 M 22 40 H 12 L 8 28\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g transform=\"translate(15,20) scale(0.8)\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 6 18 L 14 6 H 31 L 36 14 L 31 25 H 10 Z\"/><path d=\"M 36 13 H 46 L 51 21 V 29 H 49 M 37 29 H 36 V 13\"/><path d=\"M 40 17 H 45 L 47 21 H 40 Z\"/><path d=\"M 4 29 H 8 M 20 29 H 37\"/><circle cx=\"14\" cy=\"31\" r=\"5.5\"/><circle cx=\"43\" cy=\"31\" r=\"5.5\"/></g>"
      }
    }
  },
  "purchases": {
    "name": "purchases",
    "title": "Purchases",
    "group": "Inventory and Store",
    "componentName": "PurchasesIcon",
    "accessibilityLabel": "Record raw material purchase orders",
    "svg": {
      "standard": {
        "light": "<path d=\"M 10 14 H 18 L 24 40 H 48 L 54 22 H 20\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"26\" cy=\"49\" r=\"4.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><circle cx=\"45\" cy=\"49\" r=\"4.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/>",
        "dark": "<path d=\"M 10 14 H 18 L 24 40 H 48 L 54 22 H 20\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"26\" cy=\"49\" r=\"4.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><circle cx=\"45\" cy=\"49\" r=\"4.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/>"
      },
      "compact": {
        "light": "<path d=\"M 10 14 H 18 L 24 40 H 48 L 54 22 H 20\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"26\" cy=\"49\" r=\"4.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><circle cx=\"45\" cy=\"49\" r=\"4.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/>",
        "dark": "<path d=\"M 10 14 H 18 L 24 40 H 48 L 54 22 H 20\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"26\" cy=\"49\" r=\"4.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><circle cx=\"45\" cy=\"49\" r=\"4.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/>"
      }
    }
  },
  "material-receipts": {
    "name": "material-receipts",
    "title": "Material Receipts",
    "group": "Inventory and Store",
    "componentName": "MaterialReceiptsIcon",
    "accessibilityLabel": "Log inward Goods Receipt Notes (GRN) and weighbridge receipts",
    "svg": {
      "standard": {
        "light": "<path d=\"M 22 20 H 16 C 13.8 20 12 21.8 12 24 V 48 C 12 50.2 13.8 52 16 52 H 48 C 50.2 52 52 50.2 52 48 V 24 C 52 21.8 50.2 20 48 20 H 42\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 32 8 V 34 M 23 25 L 32 34 L 41 25\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 22 20 H 16 C 13.8 20 12 21.8 12 24 V 48 C 12 50.2 13.8 52 16 52 H 48 C 50.2 52 52 50.2 52 48 V 24 C 52 21.8 50.2 20 48 20 H 42\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 32 8 V 34 M 23 25 L 32 34 L 41 25\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 22 20 H 16 C 13.8 20 12 21.8 12 24 V 48 C 12 50.2 13.8 52 16 52 H 48 C 50.2 52 52 50.2 52 48 V 24 C 52 21.8 50.2 20 48 20 H 42\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 32 8 V 34 M 23 25 L 32 34 L 41 25\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 22 20 H 16 C 13.8 20 12 21.8 12 24 V 48 C 12 50.2 13.8 52 16 52 H 48 C 50.2 52 52 50.2 52 48 V 24 C 52 21.8 50.2 20 48 20 H 42\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 32 8 V 34 M 23 25 L 32 34 L 41 25\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "low-stock-alert": {
    "name": "low-stock-alert",
    "title": "Low Stock Alert",
    "group": "Inventory and Store",
    "componentName": "LowStockAlertIcon",
    "accessibilityLabel": "View critical low-stock silo and material threshold alerts",
    "svg": {
      "standard": {
        "light": "<path d=\"M 32 52 H 14 C 11.8 52 10 50.2 10 48 V 18 C 10 15.8 11.8 14 14 14 H 38 C 40.2 14 42 15.8 42 18 V 29\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"16\" y=\"40\" width=\"16\" height=\"5\" rx=\"1.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><circle cx=\"46\" cy=\"43\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 46 38.5 V 43.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"47.6\" r=\"1.6\" fill=\"#16232A\"/>",
        "dark": "<path d=\"M 32 52 H 14 C 11.8 52 10 50.2 10 48 V 18 C 10 15.8 11.8 14 14 14 H 38 C 40.2 14 42 15.8 42 18 V 29\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"16\" y=\"40\" width=\"16\" height=\"5\" rx=\"1.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><circle cx=\"46\" cy=\"43\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 46 38.5 V 43.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"47.6\" r=\"1.6\" fill=\"#E4EEF0\"/>"
      },
      "compact": {
        "light": "<path d=\"M 32 52 H 14 C 11.8 52 10 50.2 10 48 V 18 C 10 15.8 11.8 14 14 14 H 38 C 40.2 14 42 15.8 42 18 V 29\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"16\" y=\"40\" width=\"16\" height=\"5\" rx=\"1.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><circle cx=\"46\" cy=\"43\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 46 38.5 V 43.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"47.6\" r=\"1.6\" fill=\"#16232A\"/>",
        "dark": "<path d=\"M 32 52 H 14 C 11.8 52 10 50.2 10 48 V 18 C 10 15.8 11.8 14 14 14 H 38 C 40.2 14 42 15.8 42 18 V 29\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"16\" y=\"40\" width=\"16\" height=\"5\" rx=\"1.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><circle cx=\"46\" cy=\"43\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 46 38.5 V 43.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"47.6\" r=\"1.6\" fill=\"#E4EEF0\"/>"
      }
    }
  },
  "store-dashboard": {
    "name": "store-dashboard",
    "title": "Store Dashboard",
    "group": "Inventory and Store",
    "componentName": "StoreDashboardIcon",
    "accessibilityLabel": "Open plant store and inventory control dashboard",
    "svg": {
      "standard": {
        "light": "<path d=\"M 8 26 L 32 10 L 56 26 V 52 H 8 V 33\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect x=\"18\" y=\"34\" width=\"11\" height=\"18\" rx=\"1.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><rect x=\"35\" y=\"30\" width=\"11\" height=\"22\" rx=\"1.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/>",
        "dark": "<path d=\"M 8 26 L 32 10 L 56 26 V 52 H 8 V 33\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect x=\"18\" y=\"34\" width=\"11\" height=\"18\" rx=\"1.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><rect x=\"35\" y=\"30\" width=\"11\" height=\"22\" rx=\"1.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/>"
      },
      "compact": {
        "light": "<path d=\"M 8 26 L 32 10 L 56 26 V 52 H 8 V 33\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect x=\"18\" y=\"34\" width=\"11\" height=\"18\" rx=\"1.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><rect x=\"35\" y=\"30\" width=\"11\" height=\"22\" rx=\"1.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/>",
        "dark": "<path d=\"M 8 26 L 32 10 L 56 26 V 52 H 8 V 33\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect x=\"18\" y=\"34\" width=\"11\" height=\"18\" rx=\"1.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><rect x=\"35\" y=\"30\" width=\"11\" height=\"22\" rx=\"1.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/>"
      }
    }
  },
  "billing": {
    "name": "billing",
    "title": "Billing",
    "group": "Finance and Workforce",
    "componentName": "BillingIcon",
    "accessibilityLabel": "Generate GST tax invoices and customer bills",
    "svg": {
      "standard": {
        "light": "<path d=\"M 14 8 H 50 V 54 L 44 49 L 38 54 L 32 49 L 26 54 L 20 49 L 14 54 V 16\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 24 20 H 38 M 24 26 H 35 M 27 20 C 33 20 33 29 26 29 L 36 40\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 14 8 H 50 V 54 L 44 49 L 38 54 L 32 49 L 26 54 L 20 49 L 14 54 V 16\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 24 20 H 38 M 24 26 H 35 M 27 20 C 33 20 33 29 26 29 L 36 40\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 14 8 H 50 V 54 L 44 49 L 38 54 L 32 49 L 26 54 L 20 49 L 14 54 V 16\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 24 20 H 38 M 24 26 H 35 M 27 20 C 33 20 33 29 26 29 L 36 40\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 14 8 H 50 V 54 L 44 49 L 38 54 L 32 49 L 26 54 L 20 49 L 14 54 V 16\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 24 20 H 38 M 24 26 H 35 M 27 20 C 33 20 33 29 26 29 L 36 40\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "ledger": {
    "name": "ledger",
    "title": "Ledger",
    "group": "Finance and Workforce",
    "componentName": "LedgerIcon",
    "accessibilityLabel": "Inspect double-entry party and general accounting ledger",
    "svg": {
      "standard": {
        "light": "<path d=\"M 24 56 H 17 C 14.2 56 12 53.8 12 51 V 13 C 12 10.2 14.2 8 17 8 H 47 C 49.8 8 52 10.2 52 13 V 51 C 52 53.8 49.8 56 47 56 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><line x1=\"22\" y1=\"8\" x2=\"22\" y2=\"56\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 29 22 H 44 M 29 32 H 44 M 29 42 H 38\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 24 56 H 17 C 14.2 56 12 53.8 12 51 V 13 C 12 10.2 14.2 8 17 8 H 47 C 49.8 8 52 10.2 52 13 V 51 C 52 53.8 49.8 56 47 56 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><line x1=\"22\" y1=\"8\" x2=\"22\" y2=\"56\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 29 22 H 44 M 29 32 H 44 M 29 42 H 38\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 24 56 H 17 C 14.2 56 12 53.8 12 51 V 13 C 12 10.2 14.2 8 17 8 H 47 C 49.8 8 52 10.2 52 13 V 51 C 52 53.8 49.8 56 47 56 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><line x1=\"22\" y1=\"8\" x2=\"22\" y2=\"56\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 29 22 H 44 M 29 32 H 44 M 29 42 H 38\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 24 56 H 17 C 14.2 56 12 53.8 12 51 V 13 C 12 10.2 14.2 8 17 8 H 47 C 49.8 8 52 10.2 52 13 V 51 C 52 53.8 49.8 56 47 56 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><line x1=\"22\" y1=\"8\" x2=\"22\" y2=\"56\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 29 22 H 44 M 29 32 H 44 M 29 42 H 38\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "expenses": {
    "name": "expenses",
    "title": "Expenses",
    "group": "Finance and Workforce",
    "componentName": "ExpensesIcon",
    "accessibilityLabel": "Record operational, site, and petty cash expenses",
    "svg": {
      "standard": {
        "light": "<path d=\"M 52 28 V 24 C 52 20.7 49.3 18 46 18 H 14 C 10.7 18 8 20.7 8 24 V 44 C 8 47.3 10.7 50 14 50 H 46 C 49.3 50 52 47.3 52 44 V 40\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"38\" y=\"28\" width=\"16\" height=\"12\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 24 28 L 36 10 M 27 10 H 36 V 19\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 52 28 V 24 C 52 20.7 49.3 18 46 18 H 14 C 10.7 18 8 20.7 8 24 V 44 C 8 47.3 10.7 50 14 50 H 46 C 49.3 50 52 47.3 52 44 V 40\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"38\" y=\"28\" width=\"16\" height=\"12\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 24 28 L 36 10 M 27 10 H 36 V 19\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 52 28 V 24 C 52 20.7 49.3 18 46 18 H 14 C 10.7 18 8 20.7 8 24 V 44 C 8 47.3 10.7 50 14 50 H 46 C 49.3 50 52 47.3 52 44 V 40\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"38\" y=\"28\" width=\"16\" height=\"12\" rx=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 24 28 L 36 10 M 27 10 H 36 V 19\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 52 28 V 24 C 52 20.7 49.3 18 46 18 H 14 C 10.7 18 8 20.7 8 24 V 44 C 8 47.3 10.7 50 14 50 H 46 C 49.3 50 52 47.3 52 44 V 40\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"38\" y=\"28\" width=\"16\" height=\"12\" rx=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 24 28 L 36 10 M 27 10 H 36 V 19\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "payroll": {
    "name": "payroll",
    "title": "Payroll",
    "group": "Finance and Workforce",
    "componentName": "PayrollIcon",
    "accessibilityLabel": "Process monthly staff and driver salary disbursements",
    "svg": {
      "standard": {
        "light": "<path d=\"M 33 48 H 13 C 10.2 48 8 45.8 8 43 V 21 C 8 18.2 10.2 16 13 16 H 51 C 53.8 16 56 18.2 56 21 V 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"30\" cy=\"32\" r=\"7.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><circle cx=\"47\" cy=\"44\" r=\"10\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 42.8 44.3 L 45.8 47.5 L 51.8 40.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 33 48 H 13 C 10.2 48 8 45.8 8 43 V 21 C 8 18.2 10.2 16 13 16 H 51 C 53.8 16 56 18.2 56 21 V 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"30\" cy=\"32\" r=\"7.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><circle cx=\"47\" cy=\"44\" r=\"10\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 42.8 44.3 L 45.8 47.5 L 51.8 40.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 33 48 H 13 C 10.2 48 8 45.8 8 43 V 21 C 8 18.2 10.2 16 13 16 H 51 C 53.8 16 56 18.2 56 21 V 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"30\" cy=\"32\" r=\"7.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><circle cx=\"47\" cy=\"44\" r=\"10\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 42.8 44.3 L 45.8 47.5 L 51.8 40.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 33 48 H 13 C 10.2 48 8 45.8 8 43 V 21 C 8 18.2 10.2 16 13 16 H 51 C 53.8 16 56 18.2 56 21 V 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"30\" cy=\"32\" r=\"7.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><circle cx=\"47\" cy=\"44\" r=\"10\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 42.8 44.3 L 45.8 47.5 L 51.8 40.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "attendance": {
    "name": "attendance",
    "title": "Attendance",
    "group": "Finance and Workforce",
    "componentName": "AttendanceIcon",
    "accessibilityLabel": "Track daily biometric and shift attendance",
    "svg": {
      "standard": {
        "light": "<path d=\"M 31 54 H 16 C 12.7 54 10 51.3 10 48 V 18 C 10 14.7 12.7 12 16 12 H 44 C 47.3 12 50 14.7 50 18 V 30\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 10 24 H 50 M 20 8 V 16 M 40 8 V 16\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"44\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 40.8 44.3 L 43.8 47.5 L 49.8 40.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 31 54 H 16 C 12.7 54 10 51.3 10 48 V 18 C 10 14.7 12.7 12 16 12 H 44 C 47.3 12 50 14.7 50 18 V 30\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 10 24 H 50 M 20 8 V 16 M 40 8 V 16\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"44\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 40.8 44.3 L 43.8 47.5 L 49.8 40.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 31 54 H 16 C 12.7 54 10 51.3 10 48 V 18 C 10 14.7 12.7 12 16 12 H 44 C 47.3 12 50 14.7 50 18 V 30\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 10 24 H 50 M 20 8 V 16 M 40 8 V 16\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"44\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 40.8 44.3 L 43.8 47.5 L 49.8 40.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 31 54 H 16 C 12.7 54 10 51.3 10 48 V 18 C 10 14.7 12.7 12 16 12 H 44 C 47.3 12 50 14.7 50 18 V 30\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 10 24 H 50 M 20 8 V 16 M 40 8 V 16\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"45\" cy=\"44\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 40.8 44.3 L 43.8 47.5 L 49.8 40.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "shift-roster": {
    "name": "shift-roster",
    "title": "Shift Roster",
    "group": "Finance and Workforce",
    "componentName": "ShiftRosterIcon",
    "accessibilityLabel": "Schedule day and night plant shift rosters",
    "svg": {
      "standard": {
        "light": "<path d=\"M 46 18 A 20 20 0 1 0 52 32\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 32 20 V 32 L 40 37\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"48\" cy=\"16\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/>",
        "dark": "<path d=\"M 46 18 A 20 20 0 1 0 52 32\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 32 20 V 32 L 40 37\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"48\" cy=\"16\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/>"
      },
      "compact": {
        "light": "<path d=\"M 46 18 A 20 20 0 1 0 52 32\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 32 20 V 32 L 40 37\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"48\" cy=\"16\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/>",
        "dark": "<path d=\"M 46 18 A 20 20 0 1 0 52 32\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 32 20 V 32 L 40 37\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"48\" cy=\"16\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/>"
      }
    }
  },
  "my-payslip": {
    "name": "my-payslip",
    "title": "My Payslip",
    "group": "Finance and Workforce",
    "componentName": "MyPayslipIcon",
    "accessibilityLabel": "View and download personal monthly salary payslip",
    "svg": {
      "standard": {
        "light": "<path d=\"M 24 56 H 19 C 16.2 56 14 53.8 14 51 V 13 C 14 10.2 16.2 8 19 8 H 45 C 47.8 8 50 10.2 50 13 V 51 C 50 53.8 47.8 56 45 56 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"22\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 22 36 H 42 M 22 44 H 36\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 24 56 H 19 C 16.2 56 14 53.8 14 51 V 13 C 14 10.2 16.2 8 19 8 H 45 C 47.8 8 50 10.2 50 13 V 51 C 50 53.8 47.8 56 45 56 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"22\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 22 36 H 42 M 22 44 H 36\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 24 56 H 19 C 16.2 56 14 53.8 14 51 V 13 C 14 10.2 16.2 8 19 8 H 45 C 47.8 8 50 10.2 50 13 V 51 C 50 53.8 47.8 56 45 56 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"22\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 22 36 H 42 M 22 44 H 36\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 24 56 H 19 C 16.2 56 14 53.8 14 51 V 13 C 14 10.2 16.2 8 19 8 H 45 C 47.8 8 50 10.2 50 13 V 51 C 50 53.8 47.8 56 45 56 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"22\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 22 36 H 42 M 22 44 H 36\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "workforce-reports": {
    "name": "workforce-reports",
    "title": "Workforce Reports",
    "group": "Finance and Workforce",
    "componentName": "WorkforceReportsIcon",
    "accessibilityLabel": "Analyze workforce productivity and attendance reports",
    "svg": {
      "standard": {
        "light": "<circle cx=\"21\" cy=\"20\" r=\"7\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 9 40 C 11 32 16 30 21 30 C 26 30 31 32 33 40\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"35\" y=\"34\" width=\"5\" height=\"16\" rx=\"1\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><rect x=\"43.5\" y=\"26\" width=\"5\" height=\"24\" rx=\"1\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><rect x=\"52\" y=\"18\" width=\"5\" height=\"32\" rx=\"1\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/>",
        "dark": "<circle cx=\"21\" cy=\"20\" r=\"7\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 9 40 C 11 32 16 30 21 30 C 26 30 31 32 33 40\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><rect x=\"35\" y=\"34\" width=\"5\" height=\"16\" rx=\"1\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><rect x=\"43.5\" y=\"26\" width=\"5\" height=\"24\" rx=\"1\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><rect x=\"52\" y=\"18\" width=\"5\" height=\"32\" rx=\"1\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/>"
      },
      "compact": {
        "light": "<circle cx=\"21\" cy=\"20\" r=\"7\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 9 40 C 11 32 16 30 21 30 C 26 30 31 32 33 40\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"35\" y=\"34\" width=\"5\" height=\"16\" rx=\"1\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><rect x=\"43.5\" y=\"26\" width=\"5\" height=\"24\" rx=\"1\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><rect x=\"52\" y=\"18\" width=\"5\" height=\"32\" rx=\"1\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/>",
        "dark": "<circle cx=\"21\" cy=\"20\" r=\"7\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 9 40 C 11 32 16 30 21 30 C 26 30 31 32 33 40\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><rect x=\"35\" y=\"34\" width=\"5\" height=\"16\" rx=\"1\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><rect x=\"43.5\" y=\"26\" width=\"5\" height=\"24\" rx=\"1\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><rect x=\"52\" y=\"18\" width=\"5\" height=\"32\" rx=\"1\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/>"
      }
    }
  },
  "employee-master-and-salary": {
    "name": "employee-master-and-salary",
    "title": "Employee Master & Salary",
    "group": "Finance and Workforce",
    "componentName": "EmployeeMasterAndSalaryIcon",
    "accessibilityLabel": "Manage employee master records and salary structures",
    "svg": {
      "standard": {
        "light": "<path d=\"M 24 52 H 14 C 10.7 52 8 49.3 8 46 V 18 C 8 14.7 10.7 12 14 12 H 50 C 53.3 12 56 14.7 56 18 V 46 C 56 49.3 53.3 52 50 52 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"22\" cy=\"27\" r=\"5.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><path d=\"M 14 41 C 15 35 29 35 30 41\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"43\" cy=\"32\" r=\"8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><path d=\"M 40 29 H 46 M 40 32 H 45 M 41.5 29 C 44.5 29 44.5 33.5 40.5 33.5 L 45 37\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 24 52 H 14 C 10.7 52 8 49.3 8 46 V 18 C 8 14.7 10.7 12 14 12 H 50 C 53.3 12 56 14.7 56 18 V 46 C 56 49.3 53.3 52 50 52 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"22\" cy=\"27\" r=\"5.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><path d=\"M 14 41 C 15 35 29 35 30 41\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"43\" cy=\"32\" r=\"8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><path d=\"M 40 29 H 46 M 40 32 H 45 M 41.5 29 C 44.5 29 44.5 33.5 40.5 33.5 L 45 37\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 24 52 H 14 C 10.7 52 8 49.3 8 46 V 18 C 8 14.7 10.7 12 14 12 H 50 C 53.3 12 56 14.7 56 18 V 46 C 56 49.3 53.3 52 50 52 H 31\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"22\" cy=\"27\" r=\"5.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><path d=\"M 14 41 C 15 35 29 35 30 41\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"43\" cy=\"32\" r=\"8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><path d=\"M 40 29 H 46 M 40 32 H 45 M 41.5 29 C 44.5 29 44.5 33.5 40.5 33.5 L 45 37\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 24 52 H 14 C 10.7 52 8 49.3 8 46 V 18 C 8 14.7 10.7 12 14 12 H 50 C 53.3 12 56 14.7 56 18 V 46 C 56 49.3 53.3 52 50 52 H 31\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"22\" cy=\"27\" r=\"5.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><path d=\"M 14 41 C 15 35 29 35 30 41\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"43\" cy=\"32\" r=\"8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><path d=\"M 40 29 H 46 M 40 32 H 45 M 41.5 29 C 44.5 29 44.5 33.5 40.5 33.5 L 45 37\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "payroll-closure": {
    "name": "payroll-closure",
    "title": "Payroll Closure",
    "group": "Finance and Workforce",
    "componentName": "PayrollClosureIcon",
    "accessibilityLabel": "Lock and finalize monthly payroll accounting period",
    "svg": {
      "standard": {
        "light": "<path d=\"M 31 54 H 15 C 12.2 54 10 51.8 10 49 V 17 C 10 14.2 12.2 12 15 12 H 41 C 43.8 12 46 14.2 46 17 V 24\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 18 24 H 34 M 18 32 H 30 M 18 40 H 26\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><rect x=\"36\" y=\"36\" width=\"18\" height=\"15\" rx=\"3.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 40 36 V 31 A 5 5 0 0 1 50 31 V 36\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 31 54 H 15 C 12.2 54 10 51.8 10 49 V 17 C 10 14.2 12.2 12 15 12 H 41 C 43.8 12 46 14.2 46 17 V 24\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 18 24 H 34 M 18 32 H 30 M 18 40 H 26\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><rect x=\"36\" y=\"36\" width=\"18\" height=\"15\" rx=\"3.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 40 36 V 31 A 5 5 0 0 1 50 31 V 36\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 31 54 H 15 C 12.2 54 10 51.8 10 49 V 17 C 10 14.2 12.2 12 15 12 H 41 C 43.8 12 46 14.2 46 17 V 24\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 18 24 H 34 M 18 32 H 30 M 18 40 H 26\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><rect x=\"36\" y=\"36\" width=\"18\" height=\"15\" rx=\"3.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 40 36 V 31 A 5 5 0 0 1 50 31 V 36\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 31 54 H 15 C 12.2 54 10 51.8 10 49 V 17 C 10 14.2 12.2 12 15 12 H 41 C 43.8 12 46 14.2 46 17 V 24\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 18 24 H 34 M 18 32 H 30 M 18 40 H 26\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><rect x=\"36\" y=\"36\" width=\"18\" height=\"15\" rx=\"3.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 40 36 V 31 A 5 5 0 0 1 50 31 V 36\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "verified-plant": {
    "name": "verified-plant",
    "title": "Verified Plant",
    "group": "Security and Status",
    "componentName": "VerifiedPlantIcon",
    "accessibilityLabel": "Verified RMC Plant badge with green compliance checkmark",
    "svg": {
      "standard": {
        "light": "<g fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><path d=\"M 30 52 V 24 H 52 V 31\"/><path d=\"M 8 52 H 34\"/><line x1=\"16\" y1=\"26\" x2=\"22\" y2=\"26\"/><line x1=\"16\" y1=\"33\" x2=\"22\" y2=\"33\"/><rect x=\"36\" y=\"30\" width=\"10\" height=\"7\" rx=\"1.5\"/></g><circle cx=\"47\" cy=\"44\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 42.8 44.3 L 45.8 47.5 L 51.8 40.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><path d=\"M 30 52 V 24 H 52 V 31\"/><path d=\"M 8 52 H 34\"/><line x1=\"16\" y1=\"26\" x2=\"22\" y2=\"26\"/><line x1=\"16\" y1=\"33\" x2=\"22\" y2=\"33\"/><rect x=\"36\" y=\"30\" width=\"10\" height=\"7\" rx=\"1.5\"/></g><circle cx=\"47\" cy=\"44\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 42.8 44.3 L 45.8 47.5 L 51.8 40.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<g fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><path d=\"M 30 52 V 24 H 52 V 31\"/><path d=\"M 8 52 H 34\"/></g><circle cx=\"47\" cy=\"44\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 42.8 44.3 L 45.8 47.5 L 51.8 40.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><path d=\"M 30 52 V 24 H 52 V 31\"/><path d=\"M 8 52 H 34\"/></g><circle cx=\"47\" cy=\"44\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 42.8 44.3 L 45.8 47.5 L 51.8 40.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "unverified-plant": {
    "name": "unverified-plant",
    "title": "Unverified Plant",
    "group": "Security and Status",
    "componentName": "UnverifiedPlantIcon",
    "accessibilityLabel": "Unverified RMC Plant status indicator",
    "svg": {
      "standard": {
        "light": "<g fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><path d=\"M 30 52 V 24 H 52 V 31\"/><path d=\"M 8 52 H 34\"/><line x1=\"16\" y1=\"26\" x2=\"22\" y2=\"26\"/><line x1=\"16\" y1=\"33\" x2=\"22\" y2=\"33\"/><rect x=\"36\" y=\"30\" width=\"10\" height=\"7\" rx=\"1.5\"/></g><circle cx=\"47\" cy=\"44\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 47 39.5 V 44.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"47\" cy=\"48.6\" r=\"1.6\" fill=\"#16232A\"/>",
        "dark": "<g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><path d=\"M 30 52 V 24 H 52 V 31\"/><path d=\"M 8 52 H 34\"/><line x1=\"16\" y1=\"26\" x2=\"22\" y2=\"26\"/><line x1=\"16\" y1=\"33\" x2=\"22\" y2=\"33\"/><rect x=\"36\" y=\"30\" width=\"10\" height=\"7\" rx=\"1.5\"/></g><circle cx=\"47\" cy=\"44\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 47 39.5 V 44.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"47\" cy=\"48.6\" r=\"1.6\" fill=\"#E4EEF0\"/>"
      },
      "compact": {
        "light": "<g fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><path d=\"M 30 52 V 24 H 52 V 31\"/><path d=\"M 8 52 H 34\"/></g><circle cx=\"47\" cy=\"44\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 47 39.5 V 44.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"47\" cy=\"48.6\" r=\"1.6\" fill=\"#16232A\"/>",
        "dark": "<g fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M 12 20 C 12 14 26 14 26 20 V 44 H 12 Z\"/><path d=\"M 12 44 L 16 52 H 22 L 26 44\"/><path d=\"M 26 28 L 36 18 H 46\"/><path d=\"M 30 52 V 24 H 52 V 31\"/><path d=\"M 8 52 H 34\"/></g><circle cx=\"47\" cy=\"44\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 47 39.5 V 44.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"47\" cy=\"48.6\" r=\"1.6\" fill=\"#E4EEF0\"/>"
      }
    }
  },
  "kyc-verified": {
    "name": "kyc-verified",
    "title": "KYC Verified",
    "group": "Security and Status",
    "componentName": "KycVerifiedIcon",
    "accessibilityLabel": "KYC Verified badge with green identity checkmark",
    "svg": {
      "standard": {
        "light": "<path d=\"M 33 46 H 13 C 10.2 46 8 43.8 8 41 V 19 C 8 16.2 10.2 14 13 14 H 47 C 49.8 14 52 16.2 52 19 V 30\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"21\" cy=\"26\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\"/><path d=\"M 14 38 C 15 33 27 33 28 38\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><path d=\"M 34 24 H 45 M 34 31 H 41\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 42.8 45.3 L 45.8 48.5 L 51.8 41.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 33 46 H 13 C 10.2 46 8 43.8 8 41 V 19 C 8 16.2 10.2 14 13 14 H 47 C 49.8 14 52 16.2 52 19 V 30\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"21\" cy=\"26\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\"/><path d=\"M 14 38 C 15 33 27 33 28 38\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><path d=\"M 34 24 H 45 M 34 31 H 41\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"/><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 42.8 45.3 L 45.8 48.5 L 51.8 41.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 33 46 H 13 C 10.2 46 8 43.8 8 41 V 19 C 8 16.2 10.2 14 13 14 H 47 C 49.8 14 52 16.2 52 19 V 30\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"21\" cy=\"26\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><path d=\"M 14 38 C 15 33 27 33 28 38\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><path d=\"M 34 24 H 45 M 34 31 H 41\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 42.8 45.3 L 45.8 48.5 L 51.8 41.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 33 46 H 13 C 10.2 46 8 43.8 8 41 V 19 C 8 16.2 10.2 14 13 14 H 47 C 49.8 14 52 16.2 52 19 V 30\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"21\" cy=\"26\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><path d=\"M 14 38 C 15 33 27 33 28 38\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><path d=\"M 34 24 H 45 M 34 31 H 41\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/><circle cx=\"47\" cy=\"45\" r=\"10.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 42.8 45.3 L 45.8 48.5 L 51.8 41.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "pending-approval": {
    "name": "pending-approval",
    "title": "Pending Approval",
    "group": "Security and Status",
    "componentName": "PendingApprovalIcon",
    "accessibilityLabel": "Pending administrative or quality approval status",
    "svg": {
      "standard": {
        "light": "<path d=\"M 49 46 A 22 22 0 1 1 53 38\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 32 18 V 32 L 42 38\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 49 46 A 22 22 0 1 1 53 38\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 32 18 V 32 L 42 38\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 49 46 A 22 22 0 1 1 53 38\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 32 18 V 32 L 42 38\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 49 46 A 22 22 0 1 1 53 38\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 32 18 V 32 L 42 38\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "order-enabled": {
    "name": "order-enabled",
    "title": "Order Enabled",
    "group": "Security and Status",
    "componentName": "OrderEnabledIcon",
    "accessibilityLabel": "Plant order acceptance enabled toggle status",
    "svg": {
      "standard": {
        "light": "<path d=\"M 22 46 H 22 C 14.3 46 8 39.7 8 32 C 8 24.3 14.3 18 22 18 H 42 C 49.7 18 56 24.3 56 32 C 56 39.7 49.7 46 42 46 H 29\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"42\" cy=\"32\" r=\"9\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 38.5 32 L 41 34.5 L 45.5 29.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 22 46 H 22 C 14.3 46 8 39.7 8 32 C 8 24.3 14.3 18 22 18 H 42 C 49.7 18 56 24.3 56 32 C 56 39.7 49.7 46 42 46 H 29\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"42\" cy=\"32\" r=\"9\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 38.5 32 L 41 34.5 L 45.5 29.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 22 46 H 22 C 14.3 46 8 39.7 8 32 C 8 24.3 14.3 18 22 18 H 42 C 49.7 18 56 24.3 56 32 C 56 39.7 49.7 46 42 46 H 29\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"42\" cy=\"32\" r=\"9\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 38.5 32 L 41 34.5 L 45.5 29.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 22 46 H 22 C 14.3 46 8 39.7 8 32 C 8 24.3 14.3 18 22 18 H 42 C 49.7 18 56 24.3 56 32 C 56 39.7 49.7 46 42 46 H 29\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"42\" cy=\"32\" r=\"9\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 38.5 32 L 41 34.5 L 45.5 29.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  },
  "restricted-access": {
    "name": "restricted-access",
    "title": "Restricted Access",
    "group": "Security and Status",
    "componentName": "RestrictedAccessIcon",
    "accessibilityLabel": "Restricted Access security shield and masked password protection",
    "svg": {
      "standard": {
        "light": "<path d=\"M 26.8 35.5 C 22 31.8 19 26.8 19 20.2 V 11.5 C 24.2 11 28.5 9.2 32 6 C 35.5 9.2 39.8 11 45 11.5 V 20.2 C 45 25.8 42.6 30.2 39.2 33.2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"17.2\" r=\"4.6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.2\"/><path d=\"M 22.2 31.2 C 24 27.2 26.8 25.5 29.2 25.2 C 30.8 26.4 33.2 26.4 34.8 25.2 C 37.2 25.5 40 27.2 41.8 31.2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 21.5 56 H 13 C 10.2 56 8 53.8 8 51 V 40.5 C 8 37.7 10.2 35.5 13 35.5 H 51 C 53.8 35.5 56 37.7 56 40.5 V 51 C 56 53.8 53.8 56 51 56 H 25.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"><line x1=\"16.5\" y1=\"42.3\" x2=\"16.5\" y2=\"49.3\"/><line x1=\"13.47\" y1=\"44.05\" x2=\"19.53\" y2=\"47.55\"/><line x1=\"13.47\" y1=\"47.55\" x2=\"19.53\" y2=\"44.05\"/></g><g stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"><line x1=\"25.2\" y1=\"42.3\" x2=\"25.2\" y2=\"49.3\"/><line x1=\"22.169999999999998\" y1=\"44.05\" x2=\"28.23\" y2=\"47.55\"/><line x1=\"22.169999999999998\" y1=\"47.55\" x2=\"28.23\" y2=\"44.05\"/></g><g stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"><line x1=\"34.0\" y1=\"42.3\" x2=\"34.0\" y2=\"49.3\"/><line x1=\"30.97\" y1=\"44.05\" x2=\"37.03\" y2=\"47.55\"/><line x1=\"30.97\" y1=\"47.55\" x2=\"37.03\" y2=\"44.05\"/></g><rect x=\"41.8\" y=\"44.2\" width=\"9.8\" height=\"8\" rx=\"2.2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.8\"/><path d=\"M 43.8 44.2 V 41.2 A 2.9 2.9 0 0 1 49.6 41.2 V 44.2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.8\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 26.8 35.5 C 22 31.8 19 26.8 19 20.2 V 11.5 C 24.2 11 28.5 9.2 32 6 C 35.5 9.2 39.8 11 45 11.5 V 20.2 C 45 25.8 42.6 30.2 39.2 33.2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"17.2\" r=\"4.6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.2\"/><path d=\"M 22.2 31.2 C 24 27.2 26.8 25.5 29.2 25.2 C 30.8 26.4 33.2 26.4 34.8 25.2 C 37.2 25.5 40 27.2 41.8 31.2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 21.5 56 H 13 C 10.2 56 8 53.8 8 51 V 40.5 C 8 37.7 10.2 35.5 13 35.5 H 51 C 53.8 35.5 56 37.7 56 40.5 V 51 C 56 53.8 53.8 56 51 56 H 25.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"><line x1=\"16.5\" y1=\"42.3\" x2=\"16.5\" y2=\"49.3\"/><line x1=\"13.47\" y1=\"44.05\" x2=\"19.53\" y2=\"47.55\"/><line x1=\"13.47\" y1=\"47.55\" x2=\"19.53\" y2=\"44.05\"/></g><g stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"><line x1=\"25.2\" y1=\"42.3\" x2=\"25.2\" y2=\"49.3\"/><line x1=\"22.169999999999998\" y1=\"44.05\" x2=\"28.23\" y2=\"47.55\"/><line x1=\"22.169999999999998\" y1=\"47.55\" x2=\"28.23\" y2=\"44.05\"/></g><g stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"><line x1=\"34.0\" y1=\"42.3\" x2=\"34.0\" y2=\"49.3\"/><line x1=\"30.97\" y1=\"44.05\" x2=\"37.03\" y2=\"47.55\"/><line x1=\"30.97\" y1=\"47.55\" x2=\"37.03\" y2=\"44.05\"/></g><rect x=\"41.8\" y=\"44.2\" width=\"9.8\" height=\"8\" rx=\"2.2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.8\"/><path d=\"M 43.8 44.2 V 41.2 A 2.9 2.9 0 0 1 49.6 41.2 V 44.2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.8\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 23 56 H 19 C 16.2 56 14 53.8 14 51 V 33 C 14 30.2 16.2 28 19 28 H 45 C 47.8 28 50 30.2 50 33 V 51 C 50 53.8 47.8 56 45 56 H 29\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 21 28 V 20 A 11 11 0 0 1 43 20 V 28\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"40\" r=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><line x1=\"32\" y1=\"43\" x2=\"32\" y2=\"48\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
        "dark": "<path d=\"M 23 56 H 19 C 16.2 56 14 53.8 14 51 V 33 C 14 30.2 16.2 28 19 28 H 45 C 47.8 28 50 30.2 50 33 V 51 C 50 53.8 47.8 56 45 56 H 29\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 21 28 V 20 A 11 11 0 0 1 43 20 V 28\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"40\" r=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><line x1=\"32\" y1=\"43\" x2=\"32\" y2=\"48\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
      },
      "variants": {
        "avatar-shield": {
          "light": "<path d=\"M 26.8 35.5 C 22 31.8 19 26.8 19 20.2 V 11.5 C 24.2 11 28.5 9.2 32 6 C 35.5 9.2 39.8 11 45 11.5 V 20.2 C 45 25.8 42.6 30.2 39.2 33.2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"17.2\" r=\"4.6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.2\"/><path d=\"M 22.2 31.2 C 24 27.2 26.8 25.5 29.2 25.2 C 30.8 26.4 33.2 26.4 34.8 25.2 C 37.2 25.5 40 27.2 41.8 31.2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 21.5 56 H 13 C 10.2 56 8 53.8 8 51 V 40.5 C 8 37.7 10.2 35.5 13 35.5 H 51 C 53.8 35.5 56 37.7 56 40.5 V 51 C 56 53.8 53.8 56 51 56 H 25.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"><line x1=\"16.5\" y1=\"42.3\" x2=\"16.5\" y2=\"49.3\"/><line x1=\"13.47\" y1=\"44.05\" x2=\"19.53\" y2=\"47.55\"/><line x1=\"13.47\" y1=\"47.55\" x2=\"19.53\" y2=\"44.05\"/></g><g stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"><line x1=\"25.2\" y1=\"42.3\" x2=\"25.2\" y2=\"49.3\"/><line x1=\"22.169999999999998\" y1=\"44.05\" x2=\"28.23\" y2=\"47.55\"/><line x1=\"22.169999999999998\" y1=\"47.55\" x2=\"28.23\" y2=\"44.05\"/></g><g stroke=\"#16232A\" stroke-width=\"3.0\" stroke-linecap=\"round\"><line x1=\"34.0\" y1=\"42.3\" x2=\"34.0\" y2=\"49.3\"/><line x1=\"30.97\" y1=\"44.05\" x2=\"37.03\" y2=\"47.55\"/><line x1=\"30.97\" y1=\"47.55\" x2=\"37.03\" y2=\"44.05\"/></g><rect x=\"41.8\" y=\"44.2\" width=\"9.8\" height=\"8\" rx=\"2.2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.8\"/><path d=\"M 43.8 44.2 V 41.2 A 2.9 2.9 0 0 1 49.6 41.2 V 44.2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.8\" stroke-linecap=\"round\"/>",
          "dark": "<path d=\"M 26.8 35.5 C 22 31.8 19 26.8 19 20.2 V 11.5 C 24.2 11 28.5 9.2 32 6 C 35.5 9.2 39.8 11 45 11.5 V 20.2 C 45 25.8 42.6 30.2 39.2 33.2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"32\" cy=\"17.2\" r=\"4.6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.2\"/><path d=\"M 22.2 31.2 C 24 27.2 26.8 25.5 29.2 25.2 C 30.8 26.4 33.2 26.4 34.8 25.2 C 37.2 25.5 40 27.2 41.8 31.2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 21.5 56 H 13 C 10.2 56 8 53.8 8 51 V 40.5 C 8 37.7 10.2 35.5 13 35.5 H 51 C 53.8 35.5 56 37.7 56 40.5 V 51 C 56 53.8 53.8 56 51 56 H 25.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><g stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"><line x1=\"16.5\" y1=\"42.3\" x2=\"16.5\" y2=\"49.3\"/><line x1=\"13.47\" y1=\"44.05\" x2=\"19.53\" y2=\"47.55\"/><line x1=\"13.47\" y1=\"47.55\" x2=\"19.53\" y2=\"44.05\"/></g><g stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"><line x1=\"25.2\" y1=\"42.3\" x2=\"25.2\" y2=\"49.3\"/><line x1=\"22.169999999999998\" y1=\"44.05\" x2=\"28.23\" y2=\"47.55\"/><line x1=\"22.169999999999998\" y1=\"47.55\" x2=\"28.23\" y2=\"44.05\"/></g><g stroke=\"#E4EEF0\" stroke-width=\"3.0\" stroke-linecap=\"round\"><line x1=\"34.0\" y1=\"42.3\" x2=\"34.0\" y2=\"49.3\"/><line x1=\"30.97\" y1=\"44.05\" x2=\"37.03\" y2=\"47.55\"/><line x1=\"30.97\" y1=\"47.55\" x2=\"37.03\" y2=\"44.05\"/></g><rect x=\"41.8\" y=\"44.2\" width=\"9.8\" height=\"8\" rx=\"2.2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.8\"/><path d=\"M 43.8 44.2 V 41.2 A 2.9 2.9 0 0 1 49.6 41.2 V 44.2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.8\" stroke-linecap=\"round\"/>"
        },
        "browser-shield": {
          "light": "<path d=\"M 33.5 18.5 H 11.5 C 8.7 18.5 6.5 20.7 6.5 23.5 V 49.5 C 6.5 52.3 8.7 54.5 11.5 54.5 H 43.5 C 46.3 54.5 48.5 52.3 48.5 49.5 V 38.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"6.5\" y1=\"24.5\" x2=\"33.5\" y2=\"24.5\" stroke=\"#16232A\" stroke-width=\"2.6\" stroke-linecap=\"round\"/><circle cx=\"10.2\" cy=\"21.5\" r=\"1.1\" fill=\"#16232A\"/><circle cx=\"13.8\" cy=\"21.5\" r=\"1.1\" fill=\"#16232A\"/><circle cx=\"17.4\" cy=\"21.5\" r=\"1.1\" fill=\"#16232A\"/><circle cx=\"27.5\" cy=\"34.5\" r=\"6.8\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.5\"/><circle cx=\"27.5\" cy=\"32.5\" r=\"2.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.3\"/><path d=\"M 22.3 39.2 C 23.6 36.5 25.4 35.8 27.5 35.8 C 29.6 35.8 31.4 36.5 32.7 39.2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.3\" stroke-linecap=\"round\"/><g stroke=\"#16232A\" stroke-width=\"2.3\" stroke-linecap=\"round\"><line x1=\"16.5\" y1=\"44.900000000000006\" x2=\"16.5\" y2=\"49.5\"/><line x1=\"14.51\" y1=\"46.050000000000004\" x2=\"18.49\" y2=\"48.35\"/><line x1=\"14.51\" y1=\"48.35\" x2=\"18.49\" y2=\"46.050000000000004\"/></g><g stroke=\"#16232A\" stroke-width=\"2.3\" stroke-linecap=\"round\"><line x1=\"22.5\" y1=\"44.900000000000006\" x2=\"22.5\" y2=\"49.5\"/><line x1=\"20.51\" y1=\"46.050000000000004\" x2=\"24.49\" y2=\"48.35\"/><line x1=\"20.51\" y1=\"48.35\" x2=\"24.49\" y2=\"46.050000000000004\"/></g><g stroke=\"#16232A\" stroke-width=\"2.3\" stroke-linecap=\"round\"><line x1=\"28.5\" y1=\"44.900000000000006\" x2=\"28.5\" y2=\"49.5\"/><line x1=\"26.51\" y1=\"46.050000000000004\" x2=\"30.49\" y2=\"48.35\"/><line x1=\"26.51\" y1=\"48.35\" x2=\"30.49\" y2=\"46.050000000000004\"/></g><g stroke=\"#16232A\" stroke-width=\"2.3\" stroke-linecap=\"round\"><line x1=\"34.5\" y1=\"44.900000000000006\" x2=\"34.5\" y2=\"49.5\"/><line x1=\"32.51\" y1=\"46.050000000000004\" x2=\"36.49\" y2=\"48.35\"/><line x1=\"32.51\" y1=\"48.35\" x2=\"36.49\" y2=\"46.050000000000004\"/></g><line x1=\"38.5\" y1=\"49.5\" x2=\"43.5\" y2=\"49.5\" stroke=\"#16232A\" stroke-width=\"2.5\" stroke-linecap=\"round\"/><path d=\"M 47 9.5 C 43.2 12.8 39.6 14.2 36 14.8 V 27.5 C 36 33.8 41.2 38.2 47 40.8 C 52.8 38.2 58 33.8 58 27.5 V 14.8 C 54.4 14.2 50.8 12.8 47 9.5 Z\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.6\" stroke-linejoin=\"round\"/><rect x=\"42\" y=\"24.2\" width=\"10\" height=\"8.2\" rx=\"1\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.4\" stroke-linejoin=\"round\"/><path d=\"M 43.6 24.2 V 17.5 H 50.4 V 24.2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.4\" stroke-linejoin=\"round\"/><circle cx=\"47\" cy=\"27.6\" r=\"1.2\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"2.0\"/><line x1=\"47\" y1=\"28.8\" x2=\"47\" y2=\"30.4\" stroke=\"#16232A\" stroke-width=\"2.0\" stroke-linecap=\"round\"/>",
          "dark": "<path d=\"M 33.5 18.5 H 11.5 C 8.7 18.5 6.5 20.7 6.5 23.5 V 49.5 C 6.5 52.3 8.7 54.5 11.5 54.5 H 43.5 C 46.3 54.5 48.5 52.3 48.5 49.5 V 38.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"6.5\" y1=\"24.5\" x2=\"33.5\" y2=\"24.5\" stroke=\"#E4EEF0\" stroke-width=\"2.6\" stroke-linecap=\"round\"/><circle cx=\"10.2\" cy=\"21.5\" r=\"1.1\" fill=\"#E4EEF0\"/><circle cx=\"13.8\" cy=\"21.5\" r=\"1.1\" fill=\"#E4EEF0\"/><circle cx=\"17.4\" cy=\"21.5\" r=\"1.1\" fill=\"#E4EEF0\"/><circle cx=\"27.5\" cy=\"34.5\" r=\"6.8\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.5\"/><circle cx=\"27.5\" cy=\"32.5\" r=\"2.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.3\"/><path d=\"M 22.3 39.2 C 23.6 36.5 25.4 35.8 27.5 35.8 C 29.6 35.8 31.4 36.5 32.7 39.2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.3\" stroke-linecap=\"round\"/><g stroke=\"#E4EEF0\" stroke-width=\"2.3\" stroke-linecap=\"round\"><line x1=\"16.5\" y1=\"44.900000000000006\" x2=\"16.5\" y2=\"49.5\"/><line x1=\"14.51\" y1=\"46.050000000000004\" x2=\"18.49\" y2=\"48.35\"/><line x1=\"14.51\" y1=\"48.35\" x2=\"18.49\" y2=\"46.050000000000004\"/></g><g stroke=\"#E4EEF0\" stroke-width=\"2.3\" stroke-linecap=\"round\"><line x1=\"22.5\" y1=\"44.900000000000006\" x2=\"22.5\" y2=\"49.5\"/><line x1=\"20.51\" y1=\"46.050000000000004\" x2=\"24.49\" y2=\"48.35\"/><line x1=\"20.51\" y1=\"48.35\" x2=\"24.49\" y2=\"46.050000000000004\"/></g><g stroke=\"#E4EEF0\" stroke-width=\"2.3\" stroke-linecap=\"round\"><line x1=\"28.5\" y1=\"44.900000000000006\" x2=\"28.5\" y2=\"49.5\"/><line x1=\"26.51\" y1=\"46.050000000000004\" x2=\"30.49\" y2=\"48.35\"/><line x1=\"26.51\" y1=\"48.35\" x2=\"30.49\" y2=\"46.050000000000004\"/></g><g stroke=\"#E4EEF0\" stroke-width=\"2.3\" stroke-linecap=\"round\"><line x1=\"34.5\" y1=\"44.900000000000006\" x2=\"34.5\" y2=\"49.5\"/><line x1=\"32.51\" y1=\"46.050000000000004\" x2=\"36.49\" y2=\"48.35\"/><line x1=\"32.51\" y1=\"48.35\" x2=\"36.49\" y2=\"46.050000000000004\"/></g><line x1=\"38.5\" y1=\"49.5\" x2=\"43.5\" y2=\"49.5\" stroke=\"#E4EEF0\" stroke-width=\"2.5\" stroke-linecap=\"round\"/><path d=\"M 47 9.5 C 43.2 12.8 39.6 14.2 36 14.8 V 27.5 C 36 33.8 41.2 38.2 47 40.8 C 52.8 38.2 58 33.8 58 27.5 V 14.8 C 54.4 14.2 50.8 12.8 47 9.5 Z\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.6\" stroke-linejoin=\"round\"/><rect x=\"42\" y=\"24.2\" width=\"10\" height=\"8.2\" rx=\"1\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.4\" stroke-linejoin=\"round\"/><path d=\"M 43.6 24.2 V 17.5 H 50.4 V 24.2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.4\" stroke-linejoin=\"round\"/><circle cx=\"47\" cy=\"27.6\" r=\"1.2\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"2.0\"/><line x1=\"47\" y1=\"28.8\" x2=\"47\" y2=\"30.4\" stroke=\"#E4EEF0\" stroke-width=\"2.0\" stroke-linecap=\"round\"/>"
        },
        "compact-lock": {
          "light": "<path d=\"M 23 56 H 19 C 16.2 56 14 53.8 14 51 V 33 C 14 30.2 16.2 28 19 28 H 45 C 47.8 28 50 30.2 50 33 V 51 C 50 53.8 47.8 56 45 56 H 29\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 21 28 V 20 A 11 11 0 0 1 43 20 V 28\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"40\" r=\"3\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.0\"/><line x1=\"32\" y1=\"43\" x2=\"32\" y2=\"48\" stroke=\"#16232A\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>",
          "dark": "<path d=\"M 23 56 H 19 C 16.2 56 14 53.8 14 51 V 33 C 14 30.2 16.2 28 19 28 H 45 C 47.8 28 50 30.2 50 33 V 51 C 50 53.8 47.8 56 45 56 H 29\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M 21 28 V 20 A 11 11 0 0 1 43 20 V 28\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"40\" r=\"3\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.0\"/><line x1=\"32\" y1=\"43\" x2=\"32\" y2=\"48\" stroke=\"#E4EEF0\" stroke-width=\"4.0\" stroke-linecap=\"round\"/>"
        }
      }
    }
  },
  "permission-settings": {
    "name": "permission-settings",
    "title": "Permission Settings",
    "group": "Security and Status",
    "componentName": "PermissionSettingsIcon",
    "accessibilityLabel": "Configure role-based access control and module permissions",
    "svg": {
      "standard": {
        "light": "<line x1=\"12\" y1=\"18\" x2=\"19\" y2=\"18\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><line x1=\"29\" y1=\"18\" x2=\"52\" y2=\"18\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"24\" cy=\"18\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><line x1=\"12\" y1=\"34\" x2=\"35\" y2=\"34\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><line x1=\"45\" y1=\"34\" x2=\"52\" y2=\"34\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"40\" cy=\"34\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><circle cx=\"22\" cy=\"48\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\"/><path d=\"M 28 48 H 48 M 42 48 V 53 M 47 48 V 52\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>",
        "dark": "<line x1=\"12\" y1=\"18\" x2=\"19\" y2=\"18\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><line x1=\"29\" y1=\"18\" x2=\"52\" y2=\"18\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"24\" cy=\"18\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><line x1=\"12\" y1=\"34\" x2=\"35\" y2=\"34\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><line x1=\"45\" y1=\"34\" x2=\"52\" y2=\"34\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"40\" cy=\"34\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><circle cx=\"22\" cy=\"48\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\"/><path d=\"M 28 48 H 48 M 42 48 V 53 M 47 48 V 52\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/>"
      },
      "compact": {
        "light": "<line x1=\"12\" y1=\"18\" x2=\"19\" y2=\"18\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><line x1=\"29\" y1=\"18\" x2=\"52\" y2=\"18\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"24\" cy=\"18\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><line x1=\"12\" y1=\"34\" x2=\"35\" y2=\"34\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><line x1=\"45\" y1=\"34\" x2=\"52\" y2=\"34\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"40\" cy=\"34\" r=\"5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><circle cx=\"22\" cy=\"48\" r=\"6\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\"/><path d=\"M 28 48 H 48 M 42 48 V 53 M 47 48 V 52\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>",
        "dark": "<line x1=\"12\" y1=\"18\" x2=\"19\" y2=\"18\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><line x1=\"29\" y1=\"18\" x2=\"52\" y2=\"18\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"24\" cy=\"18\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><line x1=\"12\" y1=\"34\" x2=\"35\" y2=\"34\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><line x1=\"45\" y1=\"34\" x2=\"52\" y2=\"34\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"40\" cy=\"34\" r=\"5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><circle cx=\"22\" cy=\"48\" r=\"6\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\"/><path d=\"M 28 48 H 48 M 42 48 V 53 M 47 48 V 52\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/>"
      }
    }
  },
  "warning": {
    "name": "warning",
    "title": "Warning",
    "group": "Security and Status",
    "componentName": "WarningIcon",
    "accessibilityLabel": "System or operational warning alert indicator",
    "svg": {
      "standard": {
        "light": "<path d=\"M 22 52 H 8 L 32 10 L 56 52 H 29\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"32\" y1=\"25\" x2=\"32\" y2=\"38\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"45\" r=\"2.2\" fill=\"#16232A\"/>",
        "dark": "<path d=\"M 22 52 H 8 L 32 10 L 56 52 H 29\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"32\" y1=\"25\" x2=\"32\" y2=\"38\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"45\" r=\"2.2\" fill=\"#E4EEF0\"/>"
      },
      "compact": {
        "light": "<path d=\"M 22 52 H 8 L 32 10 L 56 52 H 29\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"32\" y1=\"25\" x2=\"32\" y2=\"38\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"45\" r=\"2.2\" fill=\"#16232A\"/>",
        "dark": "<path d=\"M 22 52 H 8 L 32 10 L 56 52 H 29\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"32\" y1=\"25\" x2=\"32\" y2=\"38\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><circle cx=\"32\" cy=\"45\" r=\"2.2\" fill=\"#E4EEF0\"/>"
      }
    }
  },
  "success": {
    "name": "success",
    "title": "Success",
    "group": "Security and Status",
    "componentName": "SuccessIcon",
    "accessibilityLabel": "Verified completion and success status indicator",
    "svg": {
      "standard": {
        "light": "<path d=\"M 49 46 A 22 22 0 1 1 53 38\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 22 32.5 L 29 39.5 L 43 24.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 49 46 A 22 22 0 1 1 53 38\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\"/><path d=\"M 22 32.5 L 29 39.5 L 43 24.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"3.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      },
      "compact": {
        "light": "<path d=\"M 49 46 A 22 22 0 1 1 53 38\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 22 32.5 L 29 39.5 L 43 24.5\" fill=\"none\" stroke=\"#16232A\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
        "dark": "<path d=\"M 49 46 A 22 22 0 1 1 53 38\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\"/><path d=\"M 22 32.5 L 29 39.5 L 43 24.5\" fill=\"none\" stroke=\"#E4EEF0\" stroke-width=\"4.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
      }
    }
  }
};

export function resolveTrackIconInnerSvg(
  name: TrackIconName,
  size: number = 24,
  theme: TrackIconTheme = "light",
  variant: TrackIconVariant = "default"
): string {
  const item = TRACK_ICON_REGISTRY[name];
  if (!item) return "";
  if (variant === "active" && item.svg.active) {
    return item.svg.active[theme];
  }
  if (item.svg.variants && variant in item.svg.variants) {
    return item.svg.variants[variant][theme];
  }
  if (size <= 24) {
    return item.svg.compact[theme];
  }
  return item.svg.standard[theme];
}
