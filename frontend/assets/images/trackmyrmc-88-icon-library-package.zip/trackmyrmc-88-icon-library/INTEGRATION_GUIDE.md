# TrackMyRMC 88-Icon SVG Library — Standalone Integration Guide

## 1. Safety & Non-Destructive Delivery
- **Standalone Review Package**: This package is delivered completely standalone for review.
- **Ionicons Preserved**: Existing `Ionicons` bottom tabs and screen headers inside `Aakruti7870/Track-My-RMC` (`frontend/` and `admin-web/`) remain untouched pending your explicit approval.
- **No Unapproved Mutations**: Repository integration, deployment, and permission changes require separate approval.

## 2. Master Artboard & Dynamic Sizing
- **Master Artboard**: `64 × 64` with `viewBox="0 0 64 64"`.
- **Default Display Size**: `24 × 24` (`size = 24` default prop).
- **Custom Size Rendering**: Pass any numeric `size` prop (rendered as `dp` on React Native via `react-native-svg` and CSS `px` on Web):
  ```tsx
  import { TrackIcon, NewOrderIcon, RestrictedAccessIcon } from "./src/native/TrackIcon.native";

  // Renders at default 24x24 dp
  <TrackIcon name="new-order" />

  // Renders at custom 52x52 dp with identical 0 0 64 64 viewBox scaling
  <TrackIcon name="new-order" size={52} theme="dark" />

  // Named PascalCase component export
  <NewOrderIcon size={40} theme="light" />
  ```
- **Automatic Compact Geometry (16–24 px)**: When `size <= 24`, `resolveTrackIconInnerSvg` automatically selects the simplified compact geometry with a calibrated ~2 px equivalent stroke (`stroke-width="4.8"` on the 64×64 grid = `1.8–2.0 px` at `24×24`). For `Restricted Access`, sizes `16–24 px` automatically render the clean `compact-lock` silhouette, while sizes `>= 28 px` render the full `avatar-shield` or `browser-shield` layouts.

## 3. Bottom Navigation & Restricted Access Variants
- **Bottom Navigation (`home`, `orders`, `plants`, `more`)**:
  - Outlined inactive: `<TrackIcon name="home" variant="default" />`
  - Filled active: `<TrackIcon name="home" variant="active" />`
- **Restricted Access (`restricted-access`)**:
  - Shielded avatar above password bar (Attachment 2): `<TrackIcon name="restricted-access" variant="avatar-shield" size={64} />`
  - Browser window with avatar & masked password beside shielded padlock (Attachment 1): `<TrackIcon name="restricted-access" variant="browser-shield" size={64} />`
  - Simple lock at 16–24 px: `<TrackIcon name="restricted-access" size={24} />`
