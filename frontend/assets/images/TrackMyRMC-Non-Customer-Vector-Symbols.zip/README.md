# TrackMyRMC non-customer vector symbols

129 symbols in the same 64 × 64 rounded pictogram system as the customer pack. Each symbol is supplied as an editable, recolourable SVG and as a complete warm-ivory shortcut tile. The artwork combines newly drawn symbols, shared geometry from the customer companion set where staff use the same control, and TrackMyRMC artwork adapted from the version on main.

## Coverage

- Mobile apps for Plant Owner, Driver, Plant Admin, Dispatcher, Batching Operator, Supervisor, Accountant, Quality Engineer, Fleet Manager, and Store Manager.
- Central Admin and Delegated Authority web. The map includes all 18 Central Admin menu entries and relevant access, approval, marketing, automation, and support controls. Web visibility follows the app's existing permissions.
- Non-customer sign-in, onboarding, and verification, plus the shared controls used on operational screens.

## Files

- `svg/` contains the transparent symbols using `currentColor`. Suggested sizes are 24 dp for tab and header controls and 28–32 dp for shortcuts.
- `brown-tiles/` contains complete 64 × 64 plates with #FFF0E2 icon ink, the same diagonal amber-brown gradient, and copper edges.
- `manifest.json` lists the mobile tab and module destinations by role and maps the web menu to SVG filenames.
- `previews/` contains the cover and three detailed PNG contact sheets.

Use #16232A for bare symbols on light surfaces and #E4EEF0 on dark surfaces. When using the app's existing tile component, supply a transparent SVG so it can draw its own tile treatment. Shared controls such as notifications, permissions, and sign-out are included because staff and admins use them. The customer-only route catalog is excluded.

Source revision: `66c324ff1ef30a8bfed0fbd04dd5f40ec093acee`
