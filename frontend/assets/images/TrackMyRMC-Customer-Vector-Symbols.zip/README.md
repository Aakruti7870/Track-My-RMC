# TrackMyRMC customer SVGs

53 hand-drawn glyphs based on the visual language of the supplied customer Home screenshot. The original mockup is raster artwork. These files recreate its style as editable vector geometry.

## Files

- `svg/` contains 53 transparent, recolourable glyphs with a 64 × 64 viewBox.
- `home-tiles/` contains five complete shortcut tiles with ivory ink and diagonal amber-brown backgrounds.
- `manifest.json` maps options from main and the five-tab design to the matching SVG names.
- The PNG contact sheet previews every supplied glyph and the five complete tiles.

## App use

Render the glyphs at 24 dp in navigation and 28–32 dp in shortcut cards. Set the SVG color to #FFF0E2 on brown shortcut tiles, #16232A on light surfaces, or #E4EEF0 on dark surfaces. The complete Home tiles are ready for design review. When using the app's existing icon tile component, import the transparent glyph so the tile background is rendered once.

The five reference shortcut pictograms are a mixer truck with a plus badge, a map pin over a site plan, a calculator, a boom-pump truck, and a pour calendar. Their warm fill and stroke treatment is shared across the set. The complete tiles use a copper edge and an amber-brown gradient with stops at #87532B, #603813, #472D13, and #3A2611.

The option inventory is scoped to the customer surfaces on main. Plan, Supply, Account, and the five illustrated shortcuts are compatible with the redesign in PR #234.
